(function(root){
'use strict';
const DB=root.MiseDB||(typeof require==='function'?require('../data/ingredients.js'):null);
const units=['Stück','g','kg','ml','l','Scheiben','EL','TL','Packung','Dose','Bund'];
const uid=()=>globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+Math.random().toString(36).slice(2);
const key=s=>String(s||'').toLowerCase().trim().replace(/ä/g,'ae').replace(/ö/g,'oe').replace(/ü/g,'ue').replace(/ß/g,'ss').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').replace(/\s+/g,' ').trim();
const safeName=n=>typeof n==='string'?n.trim().slice(0,80):'';
const indexes=custom=>{const all=[...DB.ingredients,...custom],byId=new Map(all.map(i=>[i.id,i])),byAlias=new Map();for(const i of all)for(const a of [i.name,...i.aliases||[]])if(!byAlias.has(key(a)))byAlias.set(key(a),i);return {all,byId,byAlias};};
let index=indexes([]);
function setCustom(custom=[]){index=indexes(custom)}
function resolve(name){return index.byId.get(name)||index.byAlias.get(key(name))||null}
function ingredient(id){return index.byId.get(id)||{id,name:'Unbekannte Zutat',category:'Sonstiges',emoji:'🥣',aliases:[]}}
function search(q,limit=8){const k=key(q);return index.all.filter(i=>!k||[i.name,...i.aliases].some(a=>key(a).includes(k))).sort((a,b)=>Number(key(b.name).startsWith(k))-Number(key(a.name).startsWith(k))).slice(0,limit)}
function ensureIngredient(state,name,category='Sonstiges'){name=safeName(name);if(!name)throw Error('Bitte einen Namen eingeben.');const known=resolve(name);if(known)return known;const custom={id:'custom_'+uid(),name,category:DB.categories.includes(category)?category:'Sonstiges',emoji:'🥣',aliases:[]};state.customIngredients.push(custom);setCustom(state.customIngredients);return custom}
function unit(u){return ({'stk':'Stück','stück':'Stück','stueck':'Stück','pieces':'Stück','piece':'Stück','gram':'g','gramm':'g','grams':'g','milliliter':'ml','liter':'l','pack':'Packung','packung':'Packung','can':'Dose','dose':'Dose','slice':'Scheiben','scheibe':'Scheiben','tbsp':'EL','tsp':'TL'})[String(u).toLowerCase()]||u}
function measure(q,u){u=unit(u);return u==='kg'?{amount:q*1000,unit:'g'}:u==='l'?{amount:q*1000,unit:'ml'}:u==='EL'?{amount:q*15,unit:'ml'}:u==='TL'?{amount:q*5,unit:'ml'}:{amount:q,unit:u}}
function makeInventoryIndex(state){const map=new Map();for(const x of state.inventory){if(!Number.isFinite(x.amount)||x.amount<=0)continue;const arr=map.get(x.ingredientId)||[];arr.push(x);map.set(x.ingredientId,arr)}return map}
function availability(req,state,servings=2,baseServings=2,inventoryIndex=makeInventoryIndex(state)){
 const need=measure(req.amount*servings/baseServings,req.unit),ids=[req.id,...DB.substitutes[req.id]||[]],items=ids.flatMap(id=>inventoryIndex.get(id)||[]),pantry=ids.some(id=>state.pantryStaples.includes(id));
 const measures=items.map(x=>measure(x.amount,x.unit)),same=measures.filter(x=>x.unit===need.unit),available=same.reduce((s,x)=>s+x.amount,0),unknown=measures.some(x=>x.unit!==need.unit);
 // A counted inventory entry always takes precedence over a pantry checkbox.
 const pantryOnly=pantry&&!items.length,missing=Math.max(0,need.amount-available),sufficient=missing<1e-8||pantryOnly;
 const status=sufficient?'enough':unknown?'unknown':items.length?'short':'missing';
 return {id:req.id,name:ingredient(req.id).name,required:need.amount,unit:need.unit,available,short:sufficient?0:missing,present:items.length>0||pantryOnly,pantry:pantryOnly,status,unknown:status==='unknown',sufficient,substitution:items.some(x=>x.ingredientId!==req.id)};
}
function match(recipe,state,servings=recipe.servings,inventoryIndex=makeInventoryIndex(state)){
 const entries=recipe.ingredients.map(i=>({...i,...availability(i,state,servings,recipe.servings,inventoryIndex)}));
 const covered=entries.filter(x=>x.sufficient||x.unknown),missing=entries.filter(x=>x.status==='short'||x.status==='missing'),unknown=entries.filter(x=>x.unknown);
 return {pct:entries.length?Math.floor(covered.length/entries.length*100):0,entries,covered,missing,unknown,complete:entries.length>0&&entries.every(x=>x.sufficient)};
}
function passes(recipe,m,filter){switch(filter){case'Alle':return true;case'Fast alles da':return m.missing.length>=1&&m.missing.length<=2;case'100 % möglich':return m.complete;case'Schnell':return recipe.time<=30;case'Unter 20 Min.':return recipe.time<=20;default:return recipe.tags.includes(filter)||recipe.category===filter}}
function addShopping(state,id,amount,u){if(!Number.isFinite(amount)||amount<=0)return;const m=measure(amount,u);let item=state.shopping.find(x=>x.ingredientId===id);if(!item){item={id:uid(),ingredientId:id,needs:[],done:false};state.shopping.push(item)}const existing=item.needs.find(x=>x.unit===m.unit);if(existing)existing.amount=Math.max(existing.amount,m.amount);else item.needs.push(m);item.done=false;return item}
function addInventory(state,item){const existing=state.inventory.find(x=>x.ingredientId===item.ingredientId&&x.unit===item.unit&&x.expiry===item.expiry);if(existing)existing.amount+=item.amount;else state.inventory.push({...item,id:uid()})}
const emptyState=()=>({version:2,inventory:[],customIngredients:[],favorites:[],shopping:[],pantryStaples:[],settings:{endpoint:'',remoteConsent:false},recent:null});
function migrate(raw){
 if(!raw||typeof raw!=='object'||!Array.isArray(raw.inventory))throw Error('Ungültiger gespeicherter Vorrat.');
 if(raw.version&&raw.version>2)throw Error('Diese Daten stammen aus einer neueren App-Version.');
 const s=emptyState();s.customIngredients=Array.isArray(raw.customIngredients)?raw.customIngredients.filter(x=>x&&typeof x.id==='string'&&/^custom_[a-zA-Z0-9_-]+$/.test(x.id)&&safeName(x.name)).map(x=>({id:x.id,name:safeName(x.name),category:DB.categories.includes(x.category)?x.category:'Sonstiges',emoji:'🥣',aliases:Array.isArray(x.aliases)?x.aliases.filter(a=>typeof a==='string').map(safeName):[]})):[];setCustom(s.customIngredients);
 for(const x of raw.inventory){if(!x||typeof x!=='object')continue;const amount=Number(x.amount??x.qty),u=unit(x.unit);if(!Number.isFinite(amount)||amount<=0||!units.includes(u))continue;let i=resolve(x.ingredientId)||resolve(x.name);if(!i&&safeName(x.name))i=ensureIngredient(s,x.name,x.category);if(!i)continue;s.inventory.push({id:uid(),ingredientId:i.id,name:safeName(x.name)||i.name,amount,unit:u,category:DB.categories.includes(x.category)?x.category:i.category,expiry:/^\d{4}-\d{2}-\d{2}$/.test(x.expiry||'')?x.expiry:''})}
 s.favorites=Array.isArray(raw.favorites)?[...new Set(raw.favorites.filter(x=>typeof x==='string'))]:[];
 s.pantryStaples=Array.isArray(raw.pantryStaples)?[...new Set(raw.pantryStaples.filter(id=>resolve(id)))]:[];
 for(const x of Array.isArray(raw.shopping)?raw.shopping:[]){if(!x)continue;let i=resolve(x.ingredientId)||resolve(x.name);if(!i&&safeName(x.name))i=ensureIngredient(s,x.name);if(!i)continue;for(const n of x.needs||[{amount:x.qty,unit:x.unit}])if(units.includes(unit(n.unit)))addShopping(s,i.id,Number(n.amount),unit(n.unit));const item=s.shopping.find(y=>y.ingredientId===i.id);if(item)item.done=!!x.done}
 if(raw.settings&&typeof raw.settings==='object'){s.settings.endpoint=typeof raw.settings.endpoint==='string'?raw.settings.endpoint.slice(0,500):'';s.settings.remoteConsent=raw.settings.remoteConsent===true;s.settings.meal=['Alle','Frühstück','Mittagessen','Abendessen'].includes(raw.settings.meal)?raw.settings.meal:'Alle';s.settings.reviewMigrated=raw.settings.reviewMigrated===true}
 s.recent=typeof raw.recent==='string'?raw.recent:null;return s;
}
function load(storage){let raw,legacy=false;try{raw=storage.getItem('mise.v2');if(raw===null){raw=storage.getItem('mise.v1');legacy=raw!==null}if(raw===null){setCustom([]);return {state:emptyState(),error:null,migrated:false}}const state=migrate(JSON.parse(raw));if(legacy)storage.setItem('mise.v1.backup',raw);return {state,error:null,migrated:legacy}}catch(error){setCustom([]);return {state:emptyState(),error:'Gespeicherte Daten konnten nicht gelesen werden. Das Original bleibt erhalten. Bitte exportiere die Sicherung im Menü, bevor du neu beginnst.',migrated:false,raw}}}
const api={DB,units,uid,key,resolve,ingredient,search,setCustom,ensureIngredient,measure,makeInventoryIndex,availability,match,passes,addShopping,addInventory,emptyState,migrate,load};root.MiseCore=api;if(typeof module!=='undefined')module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
