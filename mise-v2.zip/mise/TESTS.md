# mise v2 · Prüfbericht

Stand: 20.09.2026. **33 automatisierte Tests bestanden, 0 fehlgeschlagen.**

Ausgeführt: `node --test tests/*.cjs tests/*.mjs` unter Node.js. Syntaxprüfung für App, Core und Serverhandler ebenfalls bestanden.

## Angeforderte Fälle

| Test | Ergebnis | Prüfebene |
| --- | --- | --- |
| 1: Eier, Käse, Milch; Paprika fehlt | Genau 75 %, Paprika explizit fehlend, nicht vollständig kochbar | Core + gerendertes Karten-HTML |
| 2: alle vier Zutaten in genügender Menge | 100 %, vollständiger Match | Core |
| 3: Olivenöl hinzufügen | Deutscher und englischer Alias führen zu `olive_oil`; Speicherung/Migration erhalten ID | Core |
| 4: eigene Zutat Tahin | Eigene ID, Vorschlag „Tahin hinzufügen“, Migration erfolgreich | Core + UI-Render |
| 5: Foto an echte API-Schnittstelle senden | Frontend sendet POST mit Bilddaten; Backend setzt echten Vision-Request mit strengem JSON-Schema auf | Vertragsprüfung mit kontrolliertem Fetch, kein Live-Modell |
| 6: kein Endpoint | Klarer Nicht-verbunden-Hinweis, kein Netzaufruf, keine Fake-Zutaten | Core + UI-Render |
| 7: iPhone-Zoom | 16-px-Regel für Formulare, normaler Viewport, kein Pinch-Zoom-Verbot, umbrechende Filter | Statische CSS/HTML-Prüfung; **nicht auf echtem iPhone getestet** |
| 8: Unter 20 Minuten | Nur Zeiten <= 20, exakt 20 eingeschlossen | Core |
| 9: Paprika nie falsch als vorhanden | Alle paprikaabhängigen Rezepte verlieren 100 %, wenn Paprika fehlt | Datenbankweiter Regressionstest |

## Weitere geprüfte Punkte

- 1 von 4 Eiern → 3 fehlen; bei doppelter Portionszahl 7 fehlen.
- kg/g und l/ml; Summe mehrerer Bestandspositionen.
- Unbekannte Packungsgröße → keine Behauptung „Mit deinem Vorrat möglich“ und kein Treffer im 100-%-Filter.
- Paprika, Chili, Paprikapulver, Tomaten und Tomatenmark bleiben getrennt.
- Öl wird nicht angenommen; bestätigter Basisvorrat wird berücksichtigt; gemessener Vorrat hat Vorrang.
- Einkaufsliste dedupliziert nach ID, erhält inkompatible Einheiten in derselben Zeile.
- v1-Migration, eigene Zutaten, Favoriten und leerer Vorrat.
- Defektes JSON wird nicht still überschrieben; neuer Start ohne Demo-Zutaten.
- Mahlzeit **Frühstück/Mittagessen/Abendessen** bleibt gespeichert und kombiniert sich mit Zeitfiltern.
- 80 eindeutige vollständige Rezepte; alle IDs gültig, alle 80 Bilddateien vorhanden.
- Negative KI-Mengen und ungültige Confidence-Werte werden abgelehnt; unbekannte Mengen bleiben unbekannt.
- Kein Modell-API-Key und keine zufällige Erkennungsfunktion im Client.
- Alle vier Hauptansichten und alle 80 Detailansichten rendern im DOM-Testmodell.
- Rezeptliste rendert initial maximal 12 Karten.
- Server: Origin-Whitelist, App-Zugangscode, OPTIONS, Methodenprüfung, Payloadprüfung, fehlende Konfiguration und unvollständige Modellantworten.

## Grenzen dieser Prüfung

Die UI-Tests verwenden ein kleines DOM-Testmodell. Sie ersetzen **keinen echten Browser-, Touch-, Kamera- oder Screenreader-Test**. Eine Browser-Engine war in dieser Umgebung nicht verfügbar; deshalb wird kein bestandener Screenshot-/Mobile-Safari-Test behauptet. Die vier generierten Rezeptmotivtafeln wurden visuell geprüft; die ausgeschnittenen Assets wurden auf Existenz und Zuordnung geprüft.

Die KI-Schnittstelle ist implementiert und mit kontrollierten HTTP-Antworten getestet. Ohne eingerichtetes Backend und gültige serverseitige Zugangsdaten wurde keine kostenpflichtige Live-Analyse ausgeführt. Vor Freigabe bitte ein echtes Foto über das konfigurierte Backend analysieren, Vorschläge korrigieren und erst dann übernehmen.

Nach Deployment auf einem iPhone prüfen: Input-Fokus ohne Auto-Zoom, keine seitliche Seitenbewegung, Kamera und Mediathek, Foto-Vorschau, Einverständnis, KI-Analyse, manuelle Bestätigung, Neuladen mit erhaltenem Vorrat. HEIC-Kompatibilität hängt vom Browser ab.
