# mise · Version 2

Weiterentwicklung der bestehenden `Mise.html`, kein visuelles Redesign. Das originale Stylesheet, die Struktur mit Scan-Fläche, Milchglasflächen, Rezeptkarten, runden Buttons und Floating Navigation wurden übernommen. Das JavaScript wurde für das neue Datenmodell getrennt.

## Direkt benutzen

`index.html` öffnen. Alle Frontend-Dateien und Rezeptbilder liegen lokal im Projekt. Kein React, kein Build und keine Frontend-Abhängigkeiten nötig. Für Fotoanalyse und zuverlässige Speicherung die App über HTTPS bereitstellen. Alternativ lokal mit `python3 -m http.server 8080` starten.

Die separate `Mise.html` ist derselbe Stand mit eingebettetem CSS, JavaScript, Logo und sämtlichen Bildern. Sie eignet sich zum direkten Öffnen; für GitHub Pages ist die Ordnerfassung besser wartbar.

## Was neu ist

- 278 Zutaten mit stabilen IDs, expliziten deutschen/englischen Aliasnamen und gerichteten, vorsichtigen Ersatzregeln; freie eigene Zutaten einschließlich „Tahin“.
- 80 verschiedene lokale Rezepte mit Mengen, Portionen, Schritten, Gesamtzeiten, Kategorien, optionalen Zutaten und je einem passenden lokalen Food-Motiv.
- Eigenständige Mahlzeitenwahl **Alle / Frühstück / Mittagessen / Abendessen**, kombinierbar mit Suchfeld und allen anderen Filtern. Auswahl bleibt gespeichert.
- Bestandsprüfung berücksichtigt Mengen, kg↔g und l↔ml. Packungsgrößen werden nicht geraten.
- „100 % vorhanden / Mit deinem Vorrat möglich“ nur bei allen ausreichenden Hauptzutaten. Bei unvergleichbaren Einheiten steht ausdrücklich „Alle Zutaten da · Mengen prüfen“; kein Eintrag unter „100 % möglich“.
- „Fast alles da“ bedeutet genau 1–2 fehlende oder zu knapp vorhandene Hauptzutaten. „Unter 20 Min.“ schließt genau 20 Minuten ein. Gesamtzeit umfasst Ruhe-/Back-/Kühlzeiten.
- Sichtbarer, vom Nutzer bestätigter Basisvorrat. Konkrete gezählte Bestände überschreiben Mengenannahmen aus Basisvorrat-Häkchen. Salz/Pfeffer sind optional; erforderliches Öl wird mitgeprüft.
- Einkaufsliste dedupliziert nach Zutaten-ID. Vergleichbare Bedarfe werden als Maximum geführt, nicht addiert. Nicht vergleichbare Einheiten stehen in einer gemeinsamen Zeile zur Prüfung.
- Kamera/Galerie, echte Vorschau, JPEG-Kompression (max. 1280 px, max. 4 Bilder), echte API-Anfrage und zwingender Bestätigungsschritt. **Keine Fake-Erkennung und kein Demo-Fallback.**
- iOS-Formularfelder mindestens 16 px. Kein Abschalten von Pinch-Zoom. Filter brechen um; keine horizontale Filterleiste. Rezeptlisten laden jeweils 12 weitere Karten, Inventar jeweils 40.
- v1→v2-Migration, Datenexport/-import, Custom Ingredients, Favoriten, Einkaufslisten, Basisvorrat, Einstellungen und geräteübergreifendes manuelles Übertragen über JSON.

## GitHub Pages

1. Den **Inhalt** dieses Ordners ins Repository laden (index.html liegt an der veröffentlichten Wurzel).
2. GitHub Pages für den entsprechenden Branch/Ordner aktivieren. Keine Build-Aktion nötig.
3. Das Frontend funktioniert ohne Backend für Inventar, Rezepte, Einkaufsliste und Favoriten.
4. GitHub Pages führt `api/analyze-food.mjs` **nicht** aus. Für KI den nächsten Abschnitt verwenden.

## Echte KI-Erkennung: Vercel-Backend

Der fertige Handler nutzt die OpenAI Responses API mit Bild-Input und strengem JSON-Schema. Kein SDK nötig, nur serverseitiges `fetch` und Node.js. Es wurde kein kostenpflichtiger Cloud-Dienst eingerichtet oder Live-Modellaufruf ausgeführt.

1. Dieses Repository in Vercel importieren. Framework-Preset „Other“, keine Build-Command, Projektwurzel dieser Ordner. Vercel stellt das Frontend und die Funktion unter `/api/analyze-food` bereit.
2. Im **Vercel-Projekt**, niemals im Frontend/Repository, folgende Environment Variables setzen:

   | Variable | Wert |
   | --- | --- |
   | `OPENAI_API_KEY` | Dein privater API-Schlüssel, nur serverseitig |
   | `OPENAI_MODEL` | Ein in deinem API-Projekt verfügbares Modell mit Bild-Input, Responses und Structured Outputs |
   | `MISE_ACCESS_TOKEN` | Ein eigener zufälliger App-Zugangscode mit mindestens 32 Zeichen |
   | `ALLOWED_ORIGINS` | Exakte erlaubte Origins, z. B. `https://deinname.github.io,https://dein-projekt.vercel.app` |

   Einen zufälligen Zugangscode kannst du lokal mit `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` erzeugen. Den Wert nicht öffentlich teilen.

3. Nach Änderungen an den Servervariablen neu deployen.
4. In mise: Menü → „KI-Erkennung verbinden“.
   - Backend: `https://DEIN-PROJEKT.vercel.app/api/analyze-food`
   - App-Zugangscode: der Wert von `MISE_ACCESS_TOKEN` (**nicht** `OPENAI_API_KEY`). Der Code bleibt nur im sessionStorage dieser Sitzung; er ist nicht im Datenexport.
   - Fotoübertragung ausdrücklich erlauben.
5. Foto wählen → „Fotos senden & mit KI analysieren“ → alle Vorschläge prüfen → Bestätigungs-Häkchen → „Zum Vorrat hinzufügen“.

Fehlt der Endpunkt oder die Serverkonfiguration, meldet mise **„KI-Erkennung noch nicht verbunden“**. Sie generiert dann keinerlei Erkennungsergebnis. Eine verbundene URL allein beweist noch nicht, dass das Backend betriebsbereit ist.

### Grenzen und Sicherheit

- Für persönliche/geschlossene Nutzung ist ein nicht veröffentlichter Zugangscode vorgesehen. Vor öffentlichem Mehrbenutzerbetrieb echte Nutzeranmeldung, serverseitige pro-Nutzer-Berechtigung und persistentes Rate-Limiting ergänzen. Die vorhandene 12-Anfragen/Minute-Schranke ist nur pro warmer Serverinstanz wirksam, nicht als globale Kostenkontrolle. CORS allein ist kein Zugriffsschutz. Zusätzlich beim Provider ein Ausgabenlimit setzen.
- Die KI kann sich irren. „Confidence“ ist eine unkalibrierte Einschätzung des Modells, keine gemessene Wahrscheinlichkeit. Unbekannte Mengen bleiben leer und blockieren die Übernahme bis zur Korrektur.
- Mehrere Bilder können dasselbe Produkt zeigen; das Modell wird zum Deduplizieren angewiesen. Der Nutzer muss mögliche Dopplungen trotzdem prüfen.
- Fotos bleiben nicht im localStorage und werden erst nach aktiver Zustimmung gesendet. Das Backend protokolliert weder Bilder noch Secrets; `store:false` wird an den Modellanbieter gesendet. Etwaige anbieterseitige technische Aufbewahrung ist davon unabhängig.
- Lokal nicht decodierbare HEIC-Dateien erhalten eine klare Fehlermeldung; dann JPEG/PNG/WebP verwenden. Viele iPhone-Browser konvertieren Kameraaufnahmen bereits beim Bereitstellen.
- Bei `file://` können Browser Speicherung oder CORS einschränken. Für KI HTTPS verwenden. Die lokale Inventarfunktion bleibt ohne KI nutzbar.
- Keine medizinischen, Allergie- oder Haltbarkeitsaussagen aus Fotos. Verbrauchsdaten sind eigene Planungsdaten.

## Datenmodell und Migration

`mise.v2` speichert `inventory`, `customIngredients`, `favorites`, `shopping`, `pantryStaples`, `settings` und `recent`. Kein API-Key wird gespeichert.

Beim ersten Start wird nur dann `mise.v1` migriert, wenn noch kein v2-Stand vorliegt. Das alte JSON bleibt unangetastet und wird zusätzlich als `mise.v1.backup` gesichert. Alte Rezept-IDs wurden für die ersten 14 Gerichte erhalten. Ein leerer Vorrat bleibt leer; es gibt keine automatische Demo-Befüllung. Bei Migration erscheint ein Hinweis, den eventuell aus v1 übernommenen Demo-Vorrat zu prüfen.

Beschädigte Daten werden nicht still überschrieben. Exportieren und ggf. eine gültige Sicherung importieren. **localStorage gehört zu Browser und Origin:** Der Wechsel von einer lokalen HTML-Datei zu GitHub Pages oder auf ein anderes Gerät benötigt Export/Import. Auch private Browsermodi können Daten verwerfen.

## Bilder und Logo

80 lokale WebP-Motive, keine Hotlinks oder zufällig zugeordneten Stockbilder. Die Motive wurden mit dem integrierten Bildgenerator eigens als fotografische Darstellungen der jeweiligen Gerichte erstellt und aus vier Motivtafeln technisch ausgeschnitten. Sie sind **keine Kameraaufnahmen tatsächlich gekochter Rezepte**. Die Zuordnung und Generierungsvorgaben stehen in `assets/IMAGE-PROVENANCE.md`. Bilder laden mit `loading="lazy"` (Detail-Hauptbild bewusst eager) und besitzen einen beschrifteten Fallback.

Das Logo ist ein neues editierbares SVG: ein reduziertes M über einer Schalenkurve, Aubergine/Lavendel, ohne grünes Emoji, Kochmütze oder Sparkle.

## Tests

Mit Node.js 20 oder neuer, ohne Installation:

```sh
node --test tests/*.cjs tests/*.mjs
```

Prüfbericht: `TESTS.md`. Die API-Vertragstests verwenden kontrollierte Antworten; ein kostenpflichtiger Live-Aufruf wurde ohne eingerichtete Zugangsdaten nicht durchgeführt. Ein realer Mobile-Safari-Test bleibt nach der Bereitstellung erforderlich.

## Dateien

- `index.html`: bestehendes HTML-Gerüst ausgelagert, neue lokale Script-/Stylesheet-Referenzen.
- `assets/style.css`: unveränderte bestehende Designbasis.
- `assets/refinements.css`: gezielte Mobile-, Bild-, Formular- und Filterkorrekturen.
- `assets/logo.svg`, `assets/food/01.webp`–`80.webp`: neues Logo und Rezeptmotive.
- `data/ingredients.js`, `data/recipes.js`: größere lokale Datenbanken.
- `js/core.js`: IDs, Aliase, Mengen, Matching, Einkaufsliste und Migration.
- `js/app.js`: erhaltene Ansichten mit neuen Funktionen und Mahlzeitenwahl.
- `js/vision.js`: Bildkompression, echte Backend-Anfrage, Validierung.
- `api/analyze-food.mjs`: geschützter Serverless-Vision-Handler.
- `vercel.json`, `.env.example`, `.gitignore`: Bereitstellung und Secret-Trennung.
- `tests/`: ausführbare Regressionstests.

## Technische Referenzen

- [OpenAI: Images and vision](https://developers.openai.com/api/docs/guides/images-vision)
- [OpenAI: Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
- [Vercel: Node.js Functions](https://vercel.com/docs/functions/runtimes/node-js/advanced-node-configuration)

Rezepte sind eigene, kompakte Grundrezepte ohne Nährwertberechnung. Portionen und Zeiten sind Richtwerte. Der Tag „High Protein“ ist eine redaktionelle Rezeptgruppe, keine nachgewiesene Nährwert- oder Kennzeichnungsaussage.
