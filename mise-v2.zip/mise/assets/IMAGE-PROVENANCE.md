# Rezeptmotive

Erzeugt am 20.09.2026 über den integrierten Bildgenerator (imagegen), nicht über eine externe Stockfoto-Bibliothek oder den CLI-Fallback. Für dieses mise-Projekt erzeugt; keine fremden Fotografennamen oder Stocklizenzen werden behauptet. KI-Bilder besitzen keine garantierte Exklusivität. Die Nutzungsbedingungen des verwendeten Bildgenerierungsdienstes gelten.

## Gemeinsamer Prompt

“Use case: photorealistic-natural. Create one photographic food atlas, four columns and five rows, equal-sized tiles edge to edge, no margins, no text, no labels, no overlap. Each tile is a separate real-looking editorial food photograph with natural window light, authentic imperfect home cooking, pale warm grey/lavender table, simple modern cream ceramics. Not illustration, not CGI. Complete dish centered in its own tile. No watermark. Every cell must match its requested dish.”

Die ersten 20 Motive verlangten zusätzlich ausdrücklich realistische Texturen und keine überperfekte Präsentation. Alle vier Tafeln wurden visuell geprüft. Die Rasterzellen wurden mechanisch ohne Retusche als WebP exportiert. Einige Garnituren sind als optionale Zutaten dokumentiert.

## Prompt-Zuordnung (Datei → Motiv)

01 cremige Tomaten-Penne; 02 Paprika-Käse-Omelette; 03 Kartoffel-Paprika-Zwiebel-Pfanne; 04 Ofengemüse; 05 Gemüse-Ei-Bratreis; 06 Caprese; 07 Kartoffelgratin; 08 Bananenporridge; 09 Tomaten-Käse-Toast; 10 Spinat-Rührei; 11 Linsentopf; 12 Hähnchen-Paprika-Reis; 13 Thunfisch-Tomaten-Reis; 14 Bananen-Hafer-Pancakes; 15 Avocado-Toast; 16 Blaubeer-Walnuss-Joghurt; 17 Himbeer-Overnight-Oats; 18 Apfel-Zimt-Porridge; 19 Spiegei-Toast; 20 Shakshuka.

21 Champignon-Omelette; 22 Bananensmoothie; 23 Mango-Chia-Pudding; 24 Hüttenkäse-Radieschen-Brot; 25 Hummus-Gurken-Wrap; 26 Bruschetta; 27 Grilled Cheese; 28 Tomatensuppe; 29 Karotten-Ingwer-Suppe; 30 Kürbis-Kokos-Suppe; 31 Kartoffel-Lauch-Suppe; 32 Brokkolisuppe; 33 Minestrone; 34 Kokos-Dal; 35 Kichererbsen-Spinat-Curry; 36 Chili sin Carne; 37 Tofu-Brokkoli-Reis; 38 Lachs-Zitronen-Reis; 39 Garnelen-Knoblauch-Spaghetti; 40 Aglio e Olio.

41 Champignon-Rahm-Pasta; 42 Spinat-Ricotta-Pasta; 43 Pesto-Penne; 44 Linsenbolognese; 45 Thunfischpasta; 46 Feta-Tomaten-Pasta; 47 Mac and Cheese; 48 Gnocchi-Tomate-Mozzarella; 49 Pilzrisotto; 50 Erbsen-Zitronen-Risotto; 51 Couscous-Kichererbsen-Bowl; 52 Bulgursalat; 53 Quinoa-Avocado-Bowl; 54 Griechischer Salat; 55 Gurken-Joghurt-Salat; 56 Rote-Bete-Feta-Salat; 57 Karotten-Apfel-Salat; 58 Kartoffel-Ei-Salat; 59 Brokkoli-Kichererbsen-Salat; 60 Thunfisch-Ei-Bohnen-Salat.

61 Hähnchen-Brokkoli-Pfanne; 62 Hähnchen-Kokos-Curry; 63 Puten-Zucchini-Reis; 64 Rinderbällchen; 65 Rindfleisch-Paprika; 66 Schweinefleisch-Pilzrahm; 67 Ofenlachs-Kartoffeln; 68 Kabeljau-Tomate; 69 Garnelen-Paprika-Reis; 70 Reis-Feta-Paprika; 71 Ofen-Süßkartoffel-Kichererbsen; 72 Zucchinipuffer; 73 Kartoffelpuffer-Apfelmus; 74 Blumenkohl-Käse-Auflauf; 75 Ratatouille; 76 Apfel-Crumble; 77 Schoko-Bananen-Mousse; 78 Zitronenquark; 79 Bananenbrot; 80 Blaubeermuffins.

Dateien: `assets/food/01.webp` bis `assets/food/80.webp`. Das SVG-Logo ist separat als editierbare geometrische Grafik erstellt, nicht als generiertes Rasterbild.
