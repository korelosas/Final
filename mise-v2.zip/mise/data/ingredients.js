(function(root){
'use strict';
// Explicit aliases only. No fuzzy substring matching: paprika is never chili.
const groups={
'Gemüse':`tomato|Tomaten|Tomate,Cherry-Tomaten,Cherrytomaten,Kirschtomaten,cherry tomatoes,tomatoes
bell_pepper|Paprika|Paprika rot,rote Paprika,roter Paprika,gelbe Paprika,grüne Paprika,bell pepper,sweet pepper
onion|Zwiebeln|Zwiebel,onions,onion,rote Zwiebel,rote Zwiebeln
garlic|Knoblauch|Knoblauchzehe,Knoblauchzehen,garlic
potato|Kartoffeln|Kartoffel,potatoes,potato
sweet_potato|Süßkartoffeln|Süßkartoffel,Süsskartoffel,sweet potato
carrot|Karotten|Karotte,Möhre,Möhren,carrot,carrots
cucumber|Gurke|Gurken,Salatgurke,cucumber
zucchini|Zucchini|Zucchino,courgette
aubergine|Aubergine|Auberginen,Eierfrucht,eggplant
broccoli|Brokkoli|Broccoli,broccoli
cauliflower|Blumenkohl|cauliflower
spinach|Spinat|Blattspinat,baby spinach,spinach
leek|Lauch|Porree,leeks,leek
celery|Staudensellerie|Stangensellerie,celery
celeriac|Knollensellerie|Sellerieknolle
mushroom|Champignons|Pilze,Champignon,mushrooms,button mushrooms
corn|Mais|Dosenmais,sweetcorn,corn
peas|Erbsen|Erbse,peas
green_beans|Grüne Bohnen|grüne Bohne,green beans
pumpkin|Kürbis|Hokkaido,Butternut,pumpkin
asparagus|Spargel|grüner Spargel,weißer Spargel,asparagus
cabbage|Weißkohl|Weisskohl,Kohl,cabbage
red_cabbage|Rotkohl|Blaukraut,Rotkraut
kale|Grünkohl|kale
lettuce|Salat|Blattsalat,Kopfsalat,lettuce
rocket|Rucola|Rauke,rocket,arugula
beetroot|Rote Bete|Rote Beete,beetroot
radish|Radieschen|Radieschenbund,radish
spring_onion|Frühlingszwiebeln|Frühlingszwiebel,Lauchzwiebeln,scallions
ginger|Ingwer|ginger
fennel|Fenchel|fennel
brussels_sprouts|Rosenkohl|brussels sprouts
pak_choi|Pak Choi|Bok Choy
artichoke|Artischocken|Artischocke,artichoke
chard|Mangold|chard
turnip|Steckrübe|Steckrüben,turnip
parsnip|Pastinaken|Pastinake,parsnip
chicory|Chicorée|Chicoree,chicory
radicchio|Radicchio|
shallot|Schalotten|Schalotte,shallots
oyster_mushroom|Austernpilze|Austernpilz
shiitake|Shiitake|Shiitakepilze
okra|Okra|Okraschoten
bamboo|Bambussprossen|bamboo shoots
bean_sprouts|Mungobohnensprossen|Sojasprossen,bean sprouts`,
'Obst':`apple|Äpfel|Apfel,apple,apples
banana|Banane|Bananen,banana,bananas
orange|Orange|Orangen,orange
lemon|Zitrone|Zitronen,lemon
lime|Limette|Limetten,lime
strawberry|Erdbeeren|Erdbeere,strawberries
raspberry|Himbeeren|Himbeere,raspberries
blueberry|Blaubeeren|Blaubeere,Heidelbeeren,blueberries
grapes|Trauben|Weintrauben,grapes
mango|Mango|Mangos
pineapple|Ananas|pineapple
avocado|Avocado|Avocados
pear|Birne|Birnen,pear
peach|Pfirsich|Pfirsiche,peach
apricot|Aprikosen|Aprikose,Marillen
plum|Pflaumen|Pflaume,Zwetschgen
cherry|Kirschen|Kirsche,cherries
kiwi|Kiwi|Kiwis
melon|Honigmelone|Melone
watermelon|Wassermelone|watermelon
pomegranate|Granatapfel|Granatäpfel
fig|Feigen|Feige
dates|Datteln|Dattel,dates
blackberry|Brombeeren|Brombeere
currants|Johannisbeeren|Johannisbeere
grapefruit|Grapefruit|Pampelmuse
mandarin|Mandarinen|Mandarine,Clementinen
passionfruit|Passionsfrucht|Maracuja
coconut|Kokosnuss|coconut
rhubarb|Rhabarber|rhubarb`,
'Fleisch':`chicken_breast|Hähnchenbrust|Hähnchen,Huhn,Hühnerbrust,chicken,chicken breast
chicken_thigh|Hähnchenschenkel|Hähnchenkeule,chicken thigh
beef|Rindfleisch|Rind,beef
ground_beef|Rinderhackfleisch|Hackfleisch,Rinderhack,ground beef
steak|Rindersteak|Steak,beef steak
pork|Schweinefleisch|Schwein,pork
turkey|Putenbrust|Pute,Putenfleisch,turkey
bacon|Speck|Bacon,Frühstücksspeck
ham|Kochschinken|Schinken,ham
salami|Salami|
lamb|Lammfleisch|Lamm,lamb
sausage|Bratwurst|Bratwürste
chorizo|Chorizo|
duck|Entenbrust|Ente,duck
ground_mixed|Gemischtes Hackfleisch|Hack halb und halb
ground_pork|Schweinehackfleisch|Schweinehack
beef_strips|Rindergeschnetzeltes|Rinderstreifen`,
'Fisch & Meeresfrüchte':`salmon|Lachs|Lachsfilet,salmon
tuna_canned|Thunfisch (Dose)|Thunfisch,Dosenthunfisch,canned tuna,tuna
tuna_fresh|Thunfischsteak|frischer Thunfisch
shrimp|Garnelen|Garnele,Shrimps,shrimp,prawns
cod|Kabeljau|Kabeljaufilet,Dorsch,cod
trout|Forelle|Forellenfilet,trout
smoked_salmon|Räucherlachs|smoked salmon
pollock|Seelachs|pollock
mackerel|Makrele|mackerel
sardines|Sardinen|sardines
mussels|Miesmuscheln|Muscheln,mussels
squid|Tintenfisch|Calamari,squid
anchovy|Sardellen|Sardelle,anchovies`,
'Milchprodukte':`milk|Milch|Vollmilch,H-Milch,Frischmilch,milk
butter|Butter|butter
cream|Sahne|Schlagsahne,Kochsahne,cream
yogurt|Joghurt|Naturjoghurt,Jogurt,yogurt
greek_yogurt|Griechischer Joghurt|Greek yogurt
quark|Quark|Magerquark,Speisequark
cream_cheese|Frischkäse|cream cheese
mozzarella|Mozzarella|mozzarella
parmesan|Parmesan|Parmigiano,Parmigiano Reggiano
gouda|Gouda|Goudakäse
feta|Feta|Schafskäse,feta cheese
cheese|Käse|Reibekäse,geriebener Käse,cheese
ricotta|Ricotta|
cottage_cheese|Hüttenkäse|Körniger Frischkäse,cottage cheese
skyr|Skyr|
mascarpone|Mascarpone|
sour_cream|Saure Sahne|Sauerrahm,sour cream
creme_fraiche|Crème fraîche|Creme fraiche
cheddar|Cheddar|Cheddarkäse
emmental|Emmentaler|Emmental
halloumi|Halloumi|Grillkäse
goat_cheese|Ziegenkäse|goat cheese
buttermilk|Buttermilch|buttermilk
kefir|Kefir|
lactose_free_milk|Laktosefreie Milch|Milch laktosefrei
oat_milk|Hafermilch|Haferdrink,oat milk
almond_milk|Mandelmilch|Mandeldrink,almond milk
soy_milk|Sojamilch|Sojadrink,soy milk
soy_yogurt|Sojajoghurt|Sojajogurt`,
'Getreide & Beilagen':`rice|Reis|Langkornreis,rice
basmati|Basmatireis|Basmati,basmati rice
risotto_rice|Risottoreis|Arborio,Carnaroli
brown_rice|Naturreis|Vollkornreis,brown rice
pasta|Nudeln|Nudel,Pasta,pasta,noodles
spaghetti|Spaghetti|Spagetti
penne|Penne|
macaroni|Makkaroni|Macaroni
tagliatelle|Tagliatelle|Bandnudeln
lasagne|Lasagneplatten|Lasagneblätter
gnocchi|Gnocchi|
couscous|Couscous|Cous Cous
bulgur|Bulgur|
oats|Haferflocken|Haferflocke,oats
flour|Mehl|Weizenmehl,flour
wholemeal_flour|Vollkornmehl|Weizenvollkornmehl
bread|Brot|Bauernbrot,Mischbrot,bread
toast|Toast|Toastbrot
quinoa|Quinoa|
millet|Hirse|millet
polenta|Polenta|Maisgrieß
semolina|Grieß|Griess,Weichweizengrieß
tortilla|Tortillas|Tortilla,Wraps,Weizentortilla
puff_pastry|Blätterteig|puff pastry
breadcrumbs|Paniermehl|Semmelbrösel,breadcrumbs
rice_noodles|Reisnudeln|rice noodles
udon|Udon|Udonnudeln
soba|Soba|Sobanudeln
glass_noodles|Glasnudeln|
barley|Graupen|Perlgraupen
spelt_flour|Dinkelmehl|
buckwheat|Buchweizen|buckwheat`,
'Hülsenfrüchte':`lentils|Linsen|Linse,lentils
red_lentils|Rote Linsen|rote Linse,red lentils
chickpeas|Kichererbsen (gegart)|Kichererbsen,Chickpeas,Kichererbsen Dose
kidney_beans|Kidneybohnen (gegart)|Kidneybohnen,Kidneybohne,kidney beans
white_beans|Weiße Bohnen (gegart)|weiße Bohnen,weisse Bohnen,cannellini,white beans
black_beans|Schwarze Bohnen (gegart)|schwarze Bohnen,black beans
edamame|Edamame|Sojabohnen
tofu|Tofu|Naturtofu
smoked_tofu|Räuchertofu|smoked tofu
tempeh|Tempeh|
chickpeas_dry|Kichererbsen (trocken)|getrocknete Kichererbsen
beans_dry|Bohnen (trocken)|getrocknete Bohnen`,
'Öle & Fette':`olive_oil|Olivenöl|Olivenoel,olive oil,extra virgin olive oil,natives Olivenöl
sunflower_oil|Sonnenblumenöl|Sonnenblumenoel,sunflower oil
rapeseed_oil|Rapsöl|Rapsoel,canola oil,rapeseed oil
sesame_oil|Sesamöl|Sesamoel,sesame oil
coconut_oil|Kokosöl|Kokosoel,coconut oil
neutral_oil|Pflanzenöl|neutrales Öl,vegetable oil
ghee|Ghee|Butterschmalz
margarine|Margarine|
walnut_oil|Walnussöl|Walnussoel`,
'Saucen':`soy_sauce|Sojasauce|Sojasoße,soy sauce
ketchup|Ketchup|Tomatenketchup
mayonnaise|Mayonnaise|Mayo
mustard|Senf|Dijonsenf,mustard
sriracha|Sriracha|Srirachasauce
tomato_paste|Tomatenmark|tomato paste
passata|Passierte Tomaten|Passata,tomato passata
canned_tomato|Gehackte Tomaten (Dose)|Dosentomaten,gehackte Tomaten,chopped tomatoes
pesto|Basilikumpesto|Pesto,Pesto genovese,green pesto
red_pesto|Rotes Pesto|Pesto rosso
vinegar|Essig|Weißweinessig,Weissweinessig,vinegar
balsamic|Balsamico|Balsamicoessig
apple_vinegar|Apfelessig|
fish_sauce|Fischsauce|Fischsoße,fish sauce
oyster_sauce|Austernsauce|oyster sauce
teriyaki|Teriyakisauce|Teriyaki
harissa|Harissa|
ajvar|Ajvar|
hot_sauce|Chilisauce|Hot sauce
bbq_sauce|BBQ-Sauce|Barbecuesauce
applesauce|Apfelmus|apple sauce
hummus|Hummus|Humus`,
'Gewürze & Kräuter':`salt|Salz|Speisesalz,salt
pepper|Pfeffer|schwarzer Pfeffer,black pepper
paprika_powder|Paprikapulver|Paprika edelsüß,gemahlene Paprika
curry|Currypulver|Curry,curry powder
turmeric|Kurkuma|Turmeric
cumin|Kreuzkümmel|Cumin
oregano|Oregano|
basil|Basilikum|basil
parsley|Petersilie|parsley
rosemary|Rosmarin|rosemary
thyme|Thymian|thyme
chili|Chili|Chilischote,Chilischoten,chilli
chili_flakes|Chiliflocken|Pul Biber,Chilipulver
cinnamon|Zimt|cinnamon
nutmeg|Muskatnuss|Muskat
dill|Dill|
chives|Schnittlauch|chives
coriander|Koriander|Cilantro
bay_leaf|Lorbeer|Lorbeerblatt,Lorbeerblätter
cardamom|Kardamom|Cardamom
cloves|Nelken|Gewürznelken
smoked_paprika|Geräuchertes Paprikapulver|Paprika de la Vera
garam_masala|Garam Masala|
mint|Minze|Pfefferminze,mint
sage|Salbei|sage
saffron|Safran|saffron
sumac|Sumach|Sumak
vanilla|Vanille|Vanilleextrakt`,
'Backen':`sugar|Zucker|Kristallzucker,sugar
brown_sugar|Brauner Zucker|Rohrzucker,brown sugar
vanilla_sugar|Vanillezucker|Vanillinzucker
baking_powder|Backpulver|baking powder
baking_soda|Natron|baking soda
cocoa|Kakaopulver|Kakao,Backkakao,cocoa
yeast|Trockenhefe|Hefe,dry yeast
fresh_yeast|Frische Hefe|Hefewürfel
powdered_sugar|Puderzucker|Staubzucker
starch|Speisestärke|Maisstärke,Stärke,cornstarch
dark_chocolate|Zartbitterschokolade|dunkle Schokolade,dark chocolate
milk_chocolate|Vollmilchschokolade|Milchschokolade
gelatin|Gelatine|
agar|Agar-Agar|Agar Agar
desiccated_coconut|Kokosraspeln|Kokosflocken
raisins|Rosinen|Sultaninen`,
'Sonstiges':`egg|Eier|Ei,egg,eggs
honey|Honig|honey
nuts|Nüsse|Nuss,Nussmischung,nuts
almonds|Mandeln|Mandel,almonds
walnuts|Walnüsse|Walnuss,walnuts
cashews|Cashewkerne|Cashews
hazelnuts|Haselnüsse|Haselnuss
peanuts|Erdnüsse|Erdnuss,peanuts
peanut_butter|Erdnussbutter|Erdnussmus,peanut butter
coconut_milk|Kokosmilch|coconut milk
chia|Chiasamen|Chia
flaxseed|Leinsamen|Leinsaat
sesame|Sesam|Sesamsamen
pumpkin_seeds|Kürbiskerne|
sunflower_seeds|Sonnenblumenkerne|
olives|Oliven|Olive,olives
capers|Kapern|capers
pickles|Gewürzgurken|Essiggurken,pickles
vegetable_stock|Gemüsebrühe (Pulver)|Gemüsebrühe,Brühpulver,vegetable stock powder
maple_syrup|Ahornsirup|maple syrup
jam|Marmelade|Konfitüre,jam
coffee|Kaffee|coffee
tea|Tee|tea
water|Wasser|water`
};
const emoji={'Gemüse':'🥬','Obst':'🍎','Fleisch':'🍗','Fisch & Meeresfrüchte':'🐟','Milchprodukte':'🥛','Getreide & Beilagen':'🌾','Hülsenfrüchte':'🫘','Öle & Fette':'🫒','Saucen':'🥫','Gewürze & Kräuter':'🌿','Backen':'🧁','Sonstiges':'🥣'};
const special={tomato:'🍅',bell_pepper:'🫑',potato:'🥔',carrot:'🥕',banana:'🍌',egg:'🥚',cheese:'🧀',onion:'🧅',rice:'🍚',pasta:'🍝',lemon:'🍋',avocado:'🥑',bread:'🍞'};
const ingredients=Object.entries(groups).flatMap(([category,lines])=>lines.split('\n').map(line=>{const [id,name,aliases='']=line.split('|');return {id,name,category,aliases:aliases.split(',').filter(Boolean),emoji:special[id]||emoji[category]};}));
// Directional substitution only: a specific shape may satisfy generic pasta,
// but generic pasta does not promise that spaghetti or lasagne are available.
const substitutes={pasta:['spaghetti','penne','macaroni','tagliatelle'],rice:['basmati','brown_rice'],bread:['toast'],cheese:['gouda','cheddar','emmental'],milk:['lactose_free_milk'],yogurt:['greek_yogurt'],neutral_oil:['sunflower_oil','rapeseed_oil'],beef:['steak','beef_strips']};
const data={ingredients,categories:Object.keys(groups),substitutes};root.MiseDB=data;if(typeof module!=='undefined')module.exports=data;
})(typeof window!=='undefined'?window:globalThis);
