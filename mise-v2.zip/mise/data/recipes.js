(function(root){'use strict';
const recipes=[
  {
    "id": "pasta",
    "name": "Cremige Tomaten-Pasta",
    "ingredients": [
      {
        "id": "pasta",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "tomato",
        "amount": 3,
        "unit": "Stück"
      },
      {
        "id": "milk",
        "amount": 100,
        "unit": "ml"
      },
      {
        "id": "cheese",
        "amount": 60,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 20,
    "difficulty": "Einfach",
    "category": "Pasta",
    "servings": 2,
    "instructions": [
      "Nudeln nach Packungsangabe in Wasser garen. Vor dem Abgießen eine Tasse Kochwasser auffangen.",
      "Zwiebel fein würfeln und mit 3 EL Wasser in einer beschichteten Pfanne 4 Minuten dünsten. Tomaten würfeln, dazugeben und 6 Minuten köcheln.",
      "Milch zugeben, sanft erwärmen und den geriebenen Käse unterrühren.",
      "Nudeln mit der Sauce mischen. Mit etwas Kochwasser cremig rühren und heiß servieren."
    ],
    "tags": [
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/01.webp"
  },
  {
    "id": "omelett",
    "name": "Paprika-Käse-Omelette",
    "ingredients": [
      {
        "id": "egg",
        "amount": 4,
        "unit": "Stück"
      },
      {
        "id": "bell_pepper",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "cheese",
        "amount": 50,
        "unit": "g"
      },
      {
        "id": "milk",
        "amount": 30,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 15,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Paprika waschen, entkernen und klein würfeln. Käse reiben.",
      "Paprika mit 2 EL Wasser in einer beschichteten Pfanne zugedeckt 4 Minuten weich dünsten.",
      "Eier mit Milch verquirlen, über die Paprika geben und bei niedriger Hitze 5–7 Minuten stocken lassen.",
      "Käse darüberstreuen, Omelette zuklappen und zugedeckt kurz schmelzen lassen."
    ],
    "tags": [
      "Vegetarisch",
      "Frühstück",
      "Abendessen"
    ],
    "image": "assets/food/02.webp"
  },
  {
    "id": "potato",
    "name": "Goldene Kartoffelpfanne",
    "ingredients": [
      {
        "id": "potato",
        "amount": 600,
        "unit": "g"
      },
      {
        "id": "bell_pepper",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Abendessen",
    "servings": 2,
    "instructions": [
      "Kartoffeln schälen und in kleine Würfel schneiden. In Wasser etwa 10 Minuten vorkochen und abgießen.",
      "Zwiebel und Paprika würfeln. Öl in einer großen Pfanne erhitzen.",
      "Kartoffeln 8 Minuten goldbraun braten und gelegentlich wenden.",
      "Paprika und Zwiebeln dazugeben und weitere 7 Minuten braten, bis alles weich ist."
    ],
    "tags": [
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/03.webp"
  },
  {
    "id": "oven",
    "name": "Buntes Ofengemüse",
    "ingredients": [
      {
        "id": "potato",
        "amount": 400,
        "unit": "g"
      },
      {
        "id": "bell_pepper",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "zucchini",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 20,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 40,
    "difficulty": "Mittel",
    "category": "Abendessen",
    "servings": 2,
    "instructions": [
      "Ofen auf 200 °C Ober-/Unterhitze vorheizen. Kartoffeln in dünne Spalten schneiden.",
      "Paprika, Zucchini und Zwiebel in mundgerechte Stücke schneiden.",
      "Alles mit Öl vermengen und auf einem Blech mit Backpapier verteilen.",
      "30–35 Minuten backen, nach der Hälfte wenden. Prüfen, ob die Kartoffeln weich sind."
    ],
    "tags": [
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/04.webp"
  },
  {
    "id": "rice",
    "name": "Gebratener Gemüse-Reis",
    "ingredients": [
      {
        "id": "rice",
        "amount": 160,
        "unit": "g"
      },
      {
        "id": "egg",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "bell_pepper",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      },
      {
        "id": "peas",
        "amount": 80,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Reis",
    "servings": 2,
    "instructions": [
      "Reis nach Packungsangabe gar kochen und gut abtropfen lassen.",
      "Paprika und Zwiebel fein würfeln, im Öl 5 Minuten anbraten. Erbsen ebenfalls zugeben und vollständig garen.",
      "Gemüse zur Seite schieben. Eier in die Pfanne geben und unter Rühren vollständig stocken lassen.",
      "Reis zugeben, alles vermengen und 3 Minuten unter Wenden anbraten."
    ],
    "tags": [
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/05.webp"
  },
  {
    "id": "caprese",
    "name": "Tomate trifft Mozzarella",
    "ingredients": [
      {
        "id": "tomato",
        "amount": 3,
        "unit": "Stück"
      },
      {
        "id": "mozzarella",
        "amount": 125,
        "unit": "g"
      },
      {
        "id": "basil",
        "amount": 5,
        "unit": "g"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 10,
    "difficulty": "Einfach",
    "category": "Salate",
    "servings": 2,
    "instructions": [
      "Tomaten waschen und in Scheiben schneiden. Mozzarella abtropfen lassen und ebenfalls schneiden.",
      "Abwechselnd auf zwei Tellern anrichten.",
      "Basilikum darüberzupfen und mit Olivenöl beträufeln."
    ],
    "tags": [
      "Vegetarisch",
      "Snack",
      "Mittagessen"
    ],
    "image": "assets/food/06.webp"
  },
  {
    "id": "gratin",
    "name": "Kartoffelgratin aus dem Ofen",
    "ingredients": [
      {
        "id": "potato",
        "amount": 600,
        "unit": "g"
      },
      {
        "id": "milk",
        "amount": 300,
        "unit": "ml"
      },
      {
        "id": "cheese",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 55,
    "difficulty": "Mittel",
    "category": "Abendessen",
    "servings": 2,
    "instructions": [
      "Backofen auf 190 °C Ober-/Unterhitze vorheizen. Kartoffeln schälen und in 2 mm dünne Scheiben schneiden.",
      "Zwiebel fein würfeln und mit den Kartoffelscheiben in eine kleine Auflaufform schichten.",
      "Milch darübergeben. Mit einem Deckel oder Backpapier abdecken und 30 Minuten backen.",
      "Abdeckung entfernen, Käse darüberreiben und weitere 15–20 Minuten goldbraun backen. Die Kartoffeln müssen weich sein."
    ],
    "tags": [
      "Vegetarisch",
      "Abendessen"
    ],
    "image": "assets/food/07.webp"
  },
  {
    "id": "porridge",
    "name": "Banana Morning Bowl",
    "ingredients": [
      {
        "id": "oats",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "milk",
        "amount": 350,
        "unit": "ml"
      },
      {
        "id": "banana",
        "amount": 1,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [],
    "time": 10,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Haferflocken und Milch in einem Topf aufkochen.",
      "Bei niedriger Hitze 5 Minuten unter Rühren quellen lassen.",
      "Die Hälfte der Banane zerdrücken und unterrühren. In Schalen füllen und mit der restlichen Banane in Scheiben belegen."
    ],
    "tags": [
      "Vegetarisch",
      "Frühstück",
      "Snack"
    ],
    "image": "assets/food/08.webp"
  },
  {
    "id": "toast",
    "name": "Warmer Tomaten-Käse-Toast",
    "ingredients": [
      {
        "id": "bread",
        "amount": 4,
        "unit": "Scheiben"
      },
      {
        "id": "tomato",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "cheese",
        "amount": 80,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 12,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Ofen auf 200 °C Ober-/Unterhitze vorheizen. Brot auf ein Backblech legen.",
      "Tomaten in dünne Scheiben schneiden und auf dem Brot verteilen.",
      "Mit Käse belegen und 8–10 Minuten überbacken, bis der Käse geschmolzen ist."
    ],
    "tags": [
      "Vegetarisch",
      "Frühstück",
      "Snack"
    ],
    "image": "assets/food/09.webp"
  },
  {
    "id": "spinach",
    "name": "Spinat-Rührei",
    "ingredients": [
      {
        "id": "egg",
        "amount": 4,
        "unit": "Stück"
      },
      {
        "id": "spinach",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "milk",
        "amount": 30,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 12,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Frischen Spinat waschen und mit 2 EL Wasser in einer beschichteten Pfanne 2 Minuten zusammenfallen lassen.",
      "Eier mit Milch verquirlen und dazugeben.",
      "Bei mittlerer bis niedriger Hitze langsam mit einem Pfannenwender zusammenschieben, bis die Eier vollständig gestockt sind."
    ],
    "tags": [
      "Vegetarisch",
      "Frühstück",
      "Abendessen"
    ],
    "image": "assets/food/10.webp"
  },
  {
    "id": "lentils",
    "name": "Wärmender Linsentopf",
    "ingredients": [
      {
        "id": "red_lentils",
        "amount": 180,
        "unit": "g"
      },
      {
        "id": "tomato",
        "amount": 3,
        "unit": "Stück"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "bell_pepper",
        "amount": 1,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Abendessen",
    "servings": 2,
    "instructions": [
      "Für dieses Rezept rote Linsen verwenden. Linsen in einem Sieb abspülen. Gemüse klein würfeln.",
      "Zwiebel mit 3 EL Wasser 3 Minuten im Topf dünsten. Paprika und Tomaten zugeben und 4 Minuten garen.",
      "Linsen und 500 ml Wasser dazugeben. 15–20 Minuten sanft köcheln lassen und gelegentlich umrühren.",
      "Bei Bedarf weiteres Wasser hinzufügen, bis die gewünschte Konsistenz erreicht ist."
    ],
    "tags": [
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/11.webp"
  },
  {
    "id": "chicken",
    "name": "Hähnchen-Reis-Bowl",
    "ingredients": [
      {
        "id": "chicken_breast",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "rice",
        "amount": 160,
        "unit": "g"
      },
      {
        "id": "bell_pepper",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Reis",
    "servings": 2,
    "instructions": [
      "Reis nach Packungsangabe gar kochen. Paprika würfeln.",
      "Hähnchen mit separatem Brett und Messer in gleichmäßige kleine Stücke schneiden. Hände und Arbeitsflächen danach reinigen.",
      "Öl erhitzen, Hähnchen rundherum 8–10 Minuten braten. Paprika zugeben und weitere 5 Minuten garen. Das Fleisch muss vollständig durchgegart sein.",
      "Reis in Schalen füllen und Hähnchen mit Paprika darauf verteilen."
    ],
    "tags": [
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/12.webp"
  },
  {
    "id": "tuna",
    "name": "Mediterraner Thunfisch-Reis",
    "ingredients": [
      {
        "id": "tuna_canned",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "rice",
        "amount": 160,
        "unit": "g"
      },
      {
        "id": "tomato",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 20,
    "difficulty": "Einfach",
    "category": "Reis",
    "servings": 2,
    "instructions": [
      "Reis nach Packungsangabe kochen. Für das Rezept abgetropften Thunfisch aus der Dose verwenden.",
      "Zwiebel fein würfeln und mit 3 EL Wasser 4 Minuten dünsten.",
      "Tomaten würfeln, zugeben und 5 Minuten köcheln lassen.",
      "Thunfisch und Reis unterheben und gründlich erwärmen."
    ],
    "tags": [
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/13.webp"
  },
  {
    "id": "pancake",
    "name": "Kleine Frühstücks-Pancakes",
    "ingredients": [
      {
        "id": "oats",
        "amount": 120,
        "unit": "g"
      },
      {
        "id": "milk",
        "amount": 150,
        "unit": "ml"
      },
      {
        "id": "egg",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "banana",
        "amount": 1,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [],
    "time": 20,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Banane zerdrücken. Haferflocken im Mixer fein zerkleinern oder als kernige Variante unverändert verwenden.",
      "Mit Eiern und Milch verrühren und 5 Minuten quellen lassen.",
      "Kleine Teigportionen in einer guten beschichteten Pfanne bei mittlerer Hitze etwa 3 Minuten pro Seite backen, bis sie durchgegart sind."
    ],
    "tags": [
      "Vegetarisch",
      "Frühstück"
    ],
    "image": "assets/food/14.webp"
  },
  {
    "id": "avocado-toast",
    "name": "Avocado-Zitronen-Toast",
    "ingredients": [
      {
        "id": "bread",
        "amount": 4,
        "unit": "Scheiben"
      },
      {
        "id": "avocado",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "lemon",
        "amount": 0.5,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 10,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Brot toasten. Avocado halbieren, entkernen und das Fruchtfleisch zerdrücken.",
      "Zitrone auspressen und den Saft unter die Avocado rühren.",
      "Avocadocreme auf dem warmen Brot verteilen und direkt servieren."
    ],
    "tags": [
      "Frühstück",
      "Vegetarisch"
    ],
    "image": "assets/food/15.webp"
  },
  {
    "id": "blueberry-yogurt",
    "name": "Joghurt mit Blaubeeren & Walnüssen",
    "ingredients": [
      {
        "id": "greek_yogurt",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "blueberry",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "walnuts",
        "amount": 30,
        "unit": "g"
      },
      {
        "id": "honey",
        "amount": 10,
        "unit": "g"
      }
    ],
    "optionalIngredients": [],
    "time": 5,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Blaubeeren waschen, Walnüsse grob hacken.",
      "Joghurt auf zwei Schalen verteilen.",
      "Mit Beeren, Nüssen und Honig anrichten."
    ],
    "tags": [
      "Frühstück",
      "Vegetarisch"
    ],
    "image": "assets/food/16.webp"
  },
  {
    "id": "overnight-oats",
    "name": "Himbeer-Overnight-Oats",
    "ingredients": [
      {
        "id": "oats",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "milk",
        "amount": 200,
        "unit": "ml"
      },
      {
        "id": "yogurt",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "raspberry",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "chia",
        "amount": 10,
        "unit": "g"
      }
    ],
    "optionalIngredients": [],
    "time": 490,
    "difficulty": "Mittel",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Haferflocken, Chiasamen, Milch und Joghurt verrühren.",
      "In verschließbare Gläser füllen und mindestens 8 Stunden im Kühlschrank quellen lassen.",
      "Vor dem Essen umrühren und die gewaschenen Himbeeren darauf verteilen."
    ],
    "tags": [
      "Frühstück",
      "Vegetarisch"
    ],
    "image": "assets/food/17.webp"
  },
  {
    "id": "apple-porridge",
    "name": "Apfel-Zimt-Porridge",
    "ingredients": [
      {
        "id": "oats",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "milk",
        "amount": 350,
        "unit": "ml"
      },
      {
        "id": "apple",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "cinnamon",
        "amount": 0.5,
        "unit": "TL"
      }
    ],
    "optionalIngredients": [],
    "time": 15,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Apfel waschen, entkernen und klein würfeln.",
      "Haferflocken, Milch und zwei Drittel des Apfels in einen Topf geben.",
      "Aufkochen und bei niedriger Hitze unter Rühren 7 Minuten quellen lassen.",
      "Mit Zimt und den restlichen Apfelwürfeln servieren."
    ],
    "tags": [
      "Frühstück",
      "Vegetarisch"
    ],
    "image": "assets/food/18.webp"
  },
  {
    "id": "egg-toast",
    "name": "Spiegelei auf knusprigem Toast",
    "ingredients": [
      {
        "id": "egg",
        "amount": 4,
        "unit": "Stück"
      },
      {
        "id": "toast",
        "amount": 4,
        "unit": "Scheiben"
      },
      {
        "id": "butter",
        "amount": 10,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 10,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Toast rösten. Butter in einer beschichteten Pfanne bei mittlerer Hitze schmelzen.",
      "Eier vorsichtig hineinschlagen und 4–6 Minuten braten. Für festes Eigelb die Pfanne abdecken und länger garen.",
      "Eier auf dem Toast anrichten."
    ],
    "tags": [
      "Frühstück",
      "Vegetarisch"
    ],
    "image": "assets/food/19.webp"
  },
  {
    "id": "shakshuka",
    "name": "Shakshuka",
    "ingredients": [
      {
        "id": "egg",
        "amount": 4,
        "unit": "Stück"
      },
      {
        "id": "bell_pepper",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "canned_tomato",
        "amount": 400,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      },
      {
        "id": "cumin",
        "amount": 0.5,
        "unit": "TL"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Zwiebel und Paprika klein schneiden und im Öl 6 Minuten dünsten.",
      "Tomaten und Kreuzkümmel hinzufügen, 12 Minuten offen köcheln lassen.",
      "Vier Mulden formen, Eier einzeln hineingeben.",
      "Zugedeckt 7–9 Minuten garen, bis das Eiweiß gestockt ist."
    ],
    "tags": [
      "Frühstück",
      "Vegetarisch"
    ],
    "image": "assets/food/20.webp"
  },
  {
    "id": "mushroom-omelette",
    "name": "Champignon-Omelette",
    "ingredients": [
      {
        "id": "egg",
        "amount": 4,
        "unit": "Stück"
      },
      {
        "id": "mushroom",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "milk",
        "amount": 30,
        "unit": "ml"
      },
      {
        "id": "butter",
        "amount": 10,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 18,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Champignons putzen und in Scheiben schneiden. In der Butter 5 Minuten anbraten.",
      "Eier mit Milch verquirlen und über die Pilze gießen.",
      "Bei niedriger Hitze zugedeckt 6–8 Minuten stocken lassen.",
      "Omelette zusammenklappen und aufteilen."
    ],
    "tags": [
      "Frühstück",
      "Vegetarisch"
    ],
    "image": "assets/food/21.webp"
  },
  {
    "id": "banana-smoothie",
    "name": "Cremiger Bananen-Smoothie",
    "ingredients": [
      {
        "id": "banana",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "milk",
        "amount": 300,
        "unit": "ml"
      },
      {
        "id": "yogurt",
        "amount": 100,
        "unit": "g"
      }
    ],
    "optionalIngredients": [],
    "time": 5,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Bananen schälen und in Stücke brechen.",
      "Mit Milch und Joghurt im Mixer 30–60 Sekunden cremig pürieren.",
      "In Gläser füllen und direkt trinken."
    ],
    "tags": [
      "Frühstück",
      "Vegetarisch"
    ],
    "image": "assets/food/22.webp"
  },
  {
    "id": "mango-chia",
    "name": "Mango-Chia-Pudding",
    "ingredients": [
      {
        "id": "chia",
        "amount": 40,
        "unit": "g"
      },
      {
        "id": "coconut_milk",
        "amount": 200,
        "unit": "ml"
      },
      {
        "id": "mango",
        "amount": 1,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [],
    "time": 250,
    "difficulty": "Mittel",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Chiasamen mit Kokosmilch und 100 ml Wasser verrühren; nach 10 Minuten nochmals umrühren.",
      "Mindestens 4 Stunden abgedeckt im Kühlschrank quellen lassen.",
      "Mango schälen, Fruchtfleisch vom Stein schneiden und würfeln.",
      "Die Hälfte pürieren, auf den Pudding geben und mit den übrigen Würfeln belegen."
    ],
    "tags": [
      "Frühstück",
      "Vegetarisch"
    ],
    "image": "assets/food/23.webp"
  },
  {
    "id": "radish-bread",
    "name": "Hüttenkäse-Radieschen-Brot",
    "ingredients": [
      {
        "id": "bread",
        "amount": 4,
        "unit": "Scheiben"
      },
      {
        "id": "cottage_cheese",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "radish",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "chives",
        "amount": 5,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 10,
    "difficulty": "Einfach",
    "category": "Frühstück",
    "servings": 2,
    "instructions": [
      "Radieschen waschen und in dünne Scheiben schneiden. Schnittlauch fein schneiden.",
      "Hüttenkäse auf den Brotscheiben verteilen.",
      "Radieschen auflegen und mit Schnittlauch bestreuen."
    ],
    "tags": [
      "Frühstück",
      "Vegetarisch"
    ],
    "image": "assets/food/24.webp"
  },
  {
    "id": "hummus-wrap",
    "name": "Hummus-Gurken-Wraps",
    "ingredients": [
      {
        "id": "tortilla",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "hummus",
        "amount": 120,
        "unit": "g"
      },
      {
        "id": "cucumber",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "lettuce",
        "amount": 50,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 10,
    "difficulty": "Einfach",
    "category": "Snack",
    "servings": 2,
    "instructions": [
      "Gurke waschen und in Stifte schneiden, Salat waschen und trocknen.",
      "Tortillas in einer trockenen Pfanne kurz erwärmen und mit Hummus bestreichen.",
      "Mit Gurke und Salat belegen, Seiten einschlagen und fest aufrollen."
    ],
    "tags": [
      "Snack",
      "Vegetarisch"
    ],
    "image": "assets/food/25.webp"
  },
  {
    "id": "bruschetta",
    "name": "Tomaten-Bruschetta",
    "ingredients": [
      {
        "id": "bread",
        "amount": 4,
        "unit": "Scheiben"
      },
      {
        "id": "tomato",
        "amount": 3,
        "unit": "Stück"
      },
      {
        "id": "garlic",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      },
      {
        "id": "basil",
        "amount": 5,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 15,
    "difficulty": "Einfach",
    "category": "Snack",
    "servings": 2,
    "instructions": [
      "Tomaten fein würfeln. Basilikum zupfen und mit Tomaten und der Hälfte des Öls mischen.",
      "Brot in einer Pfanne ohne Fett oder im Toaster knusprig rösten.",
      "Knoblauchzehe halbieren und die warmen Brotscheiben damit einreiben.",
      "Tomaten darauf verteilen und mit dem restlichen Öl beträufeln."
    ],
    "tags": [
      "Snack",
      "Vegetarisch"
    ],
    "image": "assets/food/26.webp"
  },
  {
    "id": "grilled-cheese",
    "name": "Golden Grilled Cheese",
    "ingredients": [
      {
        "id": "toast",
        "amount": 4,
        "unit": "Scheiben"
      },
      {
        "id": "cheddar",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "butter",
        "amount": 15,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 12,
    "difficulty": "Einfach",
    "category": "Snack",
    "servings": 2,
    "instructions": [
      "Toast auf einer Seite dünn mit Butter bestreichen.",
      "Zwei Scheiben mit der Butterseite nach unten in eine Pfanne legen und den Käse darauf verteilen.",
      "Mit den übrigen Scheiben abdecken, Butterseite nach außen.",
      "Bei mittlerer Hitze pro Seite 3–4 Minuten goldbraun braten, bis der Käse schmilzt."
    ],
    "tags": [
      "Snack",
      "Vegetarisch"
    ],
    "image": "assets/food/27.webp"
  },
  {
    "id": "tomato-soup",
    "name": "Cremige Tomatensuppe",
    "ingredients": [
      {
        "id": "passata",
        "amount": 500,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "garlic",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "cream",
        "amount": 60,
        "unit": "ml"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Suppen",
    "servings": 2,
    "instructions": [
      "Zwiebel und Knoblauch schälen und fein würfeln.",
      "Im Öl 4 Minuten dünsten, Passata und 150 ml Wasser zugeben.",
      "15 Minuten sanft köcheln lassen, dann vorsichtig pürieren.",
      "Sahne unterrühren und kurz erwärmen."
    ],
    "tags": [
      "Suppen",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/28.webp"
  },
  {
    "id": "carrot-soup",
    "name": "Karotten-Ingwer-Suppe",
    "ingredients": [
      {
        "id": "carrot",
        "amount": 500,
        "unit": "g"
      },
      {
        "id": "ginger",
        "amount": 15,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "coconut_milk",
        "amount": 150,
        "unit": "ml"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Suppen",
    "servings": 2,
    "instructions": [
      "Karotten schälen und klein schneiden; Ingwer und Zwiebel fein würfeln.",
      "Zwiebel und Ingwer 3 Minuten im Öl dünsten.",
      "Karotten und 400 ml Wasser zugeben; zugedeckt etwa 20 Minuten weich kochen.",
      "Kokosmilch hinzufügen und die Suppe fein pürieren."
    ],
    "tags": [
      "Suppen",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/29.webp"
  },
  {
    "id": "pumpkin-soup",
    "name": "Kürbis-Kokos-Suppe",
    "ingredients": [
      {
        "id": "pumpkin",
        "amount": 600,
        "unit": "g"
      },
      {
        "id": "coconut_milk",
        "amount": 200,
        "unit": "ml"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "ginger",
        "amount": 10,
        "unit": "g"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 35,
    "difficulty": "Einfach",
    "category": "Suppen",
    "servings": 2,
    "instructions": [
      "Kürbis entkernen, bei Bedarf schälen und würfeln. Zwiebel und Ingwer klein schneiden.",
      "Zwiebel und Ingwer 3 Minuten in Öl dünsten. Kürbis und 400 ml Wasser zufügen.",
      "Etwa 25 Minuten weich köcheln.",
      "Kokosmilch zugeben und vorsichtig pürieren."
    ],
    "tags": [
      "Suppen",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/30.webp"
  },
  {
    "id": "leek-soup",
    "name": "Kartoffel-Lauch-Suppe",
    "ingredients": [
      {
        "id": "potato",
        "amount": 400,
        "unit": "g"
      },
      {
        "id": "leek",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "cream",
        "amount": 80,
        "unit": "ml"
      },
      {
        "id": "butter",
        "amount": 15,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Suppen",
    "servings": 2,
    "instructions": [
      "Kartoffeln schälen und würfeln. Lauch längs aufschneiden, gründlich waschen und in Ringe schneiden.",
      "Lauch 4 Minuten in Butter dünsten.",
      "Kartoffeln und 500 ml Wasser hinzufügen und 20 Minuten weich kochen.",
      "Sahne einrühren, einen Teil der Suppe pürieren und wieder untermischen."
    ],
    "tags": [
      "Suppen",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/31.webp"
  },
  {
    "id": "broccoli-soup",
    "name": "Sanfte Brokkoli-Cremesuppe",
    "ingredients": [
      {
        "id": "broccoli",
        "amount": 400,
        "unit": "g"
      },
      {
        "id": "potato",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "cream",
        "amount": 80,
        "unit": "ml"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Suppen",
    "servings": 2,
    "instructions": [
      "Zwiebel und Kartoffel schälen und würfeln; Brokkoli in kleine Röschen teilen.",
      "Zwiebel und Kartoffel mit 500 ml Wasser 10 Minuten köcheln.",
      "Brokkoli dazugeben und weitere 8 Minuten weich garen.",
      "Sahne zufügen und die Suppe vorsichtig pürieren."
    ],
    "tags": [
      "Suppen",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/32.webp"
  },
  {
    "id": "minestrone",
    "name": "Gemüse-Minestrone",
    "ingredients": [
      {
        "id": "carrot",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "zucchini",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "white_beans",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "pasta",
        "amount": 70,
        "unit": "g"
      },
      {
        "id": "canned_tomato",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 35,
    "difficulty": "Einfach",
    "category": "Suppen",
    "servings": 2,
    "instructions": [
      "Zwiebel, Karotte und Zucchini klein würfeln.",
      "Zwiebel und Karotte 5 Minuten in Öl dünsten. Tomaten und 600 ml Wasser zugeben.",
      "10 Minuten köcheln lassen, dann kleine Nudeln und Zucchini hinzufügen.",
      "Nach Nudel-Packungsangabe weitergaren. Abgespülte, gegarte weiße Bohnen in den letzten 5 Minuten zugeben."
    ],
    "tags": [
      "Suppen",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/33.webp"
  },
  {
    "id": "coconut-dal",
    "name": "Rotes Linsen-Kokos-Dal",
    "ingredients": [
      {
        "id": "red_lentils",
        "amount": 180,
        "unit": "g"
      },
      {
        "id": "coconut_milk",
        "amount": 200,
        "unit": "ml"
      },
      {
        "id": "canned_tomato",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "curry",
        "amount": 1,
        "unit": "TL"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Hülsenfrüchte",
    "servings": 2,
    "instructions": [
      "Rote Linsen abspülen. Zwiebel würfeln und 4 Minuten in Öl dünsten.",
      "Curry kurz mitrösten. Tomaten, Linsen, Kokosmilch und 200 ml Wasser zugeben.",
      "18–20 Minuten sanft köcheln, regelmäßig umrühren.",
      "Bei Bedarf etwas Wasser ergänzen, bis die Linsen weich sind."
    ],
    "tags": [
      "Hülsenfrüchte",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/34.webp"
  },
  {
    "id": "chickpea-curry",
    "name": "Kichererbsen-Spinat-Curry",
    "ingredients": [
      {
        "id": "chickpeas",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "spinach",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "coconut_milk",
        "amount": 200,
        "unit": "ml"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "curry",
        "amount": 1,
        "unit": "TL"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Hülsenfrüchte",
    "servings": 2,
    "instructions": [
      "Zwiebel fein würfeln und 4 Minuten im Öl dünsten. Curry kurz unterrühren.",
      "Abgespülte, gegarte Kichererbsen und Kokosmilch hinzufügen und 10 Minuten köcheln.",
      "Gewaschenen Spinat zugeben und 3–5 Minuten zusammenfallen lassen.",
      "Bei Bedarf mit etwas Wasser verdünnen."
    ],
    "tags": [
      "Hülsenfrüchte",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/35.webp"
  },
  {
    "id": "chili-sin-carne",
    "name": "Chili sin Carne",
    "ingredients": [
      {
        "id": "kidney_beans",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "corn",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "canned_tomato",
        "amount": 400,
        "unit": "g"
      },
      {
        "id": "bell_pepper",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "cumin",
        "amount": 1,
        "unit": "TL"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Hülsenfrüchte",
    "servings": 2,
    "instructions": [
      "Zwiebel und Paprika würfeln, 5 Minuten in Öl anbraten.",
      "Tomaten und Kreuzkümmel zugeben und 10 Minuten köcheln.",
      "Gegarte Kidneybohnen und Mais abspülen, dazugeben und weitere 10 Minuten köcheln.",
      "Bei Bedarf etwas Wasser zufügen; optional mit Chili abschmecken."
    ],
    "tags": [
      "Hülsenfrüchte",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/36.webp"
  },
  {
    "id": "tofu-bowl",
    "name": "Tofu-Brokkoli-Reis-Bowl",
    "ingredients": [
      {
        "id": "tofu",
        "amount": 250,
        "unit": "g"
      },
      {
        "id": "broccoli",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "rice",
        "amount": 160,
        "unit": "g"
      },
      {
        "id": "soy_sauce",
        "amount": 20,
        "unit": "ml"
      },
      {
        "id": "sesame_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Bowls",
    "servings": 2,
    "instructions": [
      "Reis nach Packungsangabe kochen. Brokkoli in Röschen teilen und 5 Minuten dämpfen.",
      "Tofu trocken tupfen und würfeln. In Sesamöl 7–8 Minuten rundherum anbraten.",
      "Brokkoli und Sojasauce zugeben, 2 Minuten durchschwenken.",
      "Mit dem Reis in Schalen anrichten."
    ],
    "tags": [
      "Bowls",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/37.webp"
  },
  {
    "id": "salmon-bowl",
    "name": "Lachs-Zitronen-Reis-Bowl",
    "ingredients": [
      {
        "id": "salmon",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "rice",
        "amount": 160,
        "unit": "g"
      },
      {
        "id": "lemon",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Fisch",
    "servings": 2,
    "instructions": [
      "Reis nach Packungsangabe kochen. Lachs trocken tupfen.",
      "Öl in einer Pfanne erhitzen und den Lachs je nach Dicke etwa 4–5 Minuten je Seite vollständig garen.",
      "Zitrone halbieren und etwas Saft über den Lachs geben.",
      "Reis in Schalen verteilen, Lachs darauflegen und mit Zitronenspalten servieren."
    ],
    "tags": [
      "Fisch",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/38.webp"
  },
  {
    "id": "shrimp-pasta",
    "name": "Garnelen-Knoblauch-Spaghetti",
    "ingredients": [
      {
        "id": "spaghetti",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "shrimp",
        "amount": 250,
        "unit": "g"
      },
      {
        "id": "garlic",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 20,
        "unit": "ml"
      },
      {
        "id": "parsley",
        "amount": 5,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 20,
    "difficulty": "Einfach",
    "category": "Pasta",
    "servings": 2,
    "instructions": [
      "Spaghetti nach Packungsangabe kochen, etwas Kochwasser aufheben.",
      "Geschälte Garnelen trocken tupfen, Knoblauch fein schneiden.",
      "Öl erhitzen, Garnelen pro Seite 2–3 Minuten garen, bis sie innen nicht mehr glasig sind. Knoblauch während der letzten Minute zugeben.",
      "Pasta und gehackte Petersilie unterheben und mit etwas Kochwasser lockern."
    ],
    "tags": [
      "Pasta",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/39.webp"
  },
  {
    "id": "aglio-olio",
    "name": "Spaghetti Aglio e Olio",
    "ingredients": [
      {
        "id": "spaghetti",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "garlic",
        "amount": 3,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 30,
        "unit": "ml"
      },
      {
        "id": "parsley",
        "amount": 10,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 20,
    "difficulty": "Einfach",
    "category": "Pasta",
    "servings": 2,
    "instructions": [
      "Spaghetti in Wasser nach Packungsangabe garen. Eine Tasse Kochwasser aufheben.",
      "Knoblauch in dünne Scheiben schneiden und im Öl bei niedriger Hitze 3–4 Minuten duften lassen, nicht bräunen.",
      "Spaghetti und etwas Kochwasser hinzugeben, gründlich durchschwenken.",
      "Gehackte Petersilie unterheben; optional Chiliflocken ergänzen."
    ],
    "tags": [
      "Pasta",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/40.webp"
  },
  {
    "id": "mushroom-pasta",
    "name": "Champignon-Rahm-Pasta",
    "ingredients": [
      {
        "id": "pasta",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "mushroom",
        "amount": 250,
        "unit": "g"
      },
      {
        "id": "cream",
        "amount": 150,
        "unit": "ml"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "butter",
        "amount": 15,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Pasta",
    "servings": 2,
    "instructions": [
      "Nudeln nach Packungsangabe kochen.",
      "Champignons putzen und schneiden; Zwiebel fein würfeln.",
      "In Butter etwa 8 Minuten anbraten, bis die Pilze Farbe annehmen.",
      "Sahne hinzufügen, 3 Minuten köcheln und mit den Nudeln mischen."
    ],
    "tags": [
      "Pasta",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/41.webp"
  },
  {
    "id": "spinach-ricotta",
    "name": "Spinat-Ricotta-Pasta",
    "ingredients": [
      {
        "id": "pasta",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "spinach",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "ricotta",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "garlic",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 20,
    "difficulty": "Einfach",
    "category": "Pasta",
    "servings": 2,
    "instructions": [
      "Nudeln garen und etwas Kochwasser aufheben.",
      "Gehackten Knoblauch in Öl kurz dünsten, gewaschenen Spinat dazugeben und zusammenfallen lassen.",
      "Ricotta und etwas Kochwasser unterrühren.",
      "Nudeln dazugeben und alles bei milder Hitze cremig vermengen."
    ],
    "tags": [
      "Pasta",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/42.webp"
  },
  {
    "id": "pesto-penne",
    "name": "Penne mit Basilikumpesto",
    "ingredients": [
      {
        "id": "penne",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "pesto",
        "amount": 70,
        "unit": "g"
      },
      {
        "id": "parmesan",
        "amount": 30,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 15,
    "difficulty": "Einfach",
    "category": "Pasta",
    "servings": 2,
    "instructions": [
      "Penne nach Packungsangabe bissfest kochen, eine kleine Tasse Kochwasser aufheben.",
      "Pesto in einer Schüssel mit 2–3 EL Kochwasser verrühren.",
      "Abgetropfte Penne untermischen und geriebenen Parmesan darübergeben."
    ],
    "tags": [
      "Pasta",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/43.webp"
  },
  {
    "id": "lentil-bolognese",
    "name": "Spaghetti mit Linsenbolognese",
    "ingredients": [
      {
        "id": "spaghetti",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "red_lentils",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "passata",
        "amount": 400,
        "unit": "g"
      },
      {
        "id": "carrot",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 35,
    "difficulty": "Einfach",
    "category": "Pasta",
    "servings": 2,
    "instructions": [
      "Zwiebel und Karotte fein würfeln, 5 Minuten im Öl dünsten.",
      "Abgespülte rote Linsen, Passata und 250 ml Wasser zugeben.",
      "20 Minuten köcheln lassen, bei Bedarf Wasser ergänzen.",
      "Spaghetti separat kochen und mit der Linsensauce servieren."
    ],
    "tags": [
      "Pasta",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/44.webp"
  },
  {
    "id": "tuna-pasta",
    "name": "Thunfisch-Tomaten-Pasta",
    "ingredients": [
      {
        "id": "pasta",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "tuna_canned",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "passata",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 20,
    "difficulty": "Einfach",
    "category": "Pasta",
    "servings": 2,
    "instructions": [
      "Nudeln nach Packungsangabe kochen.",
      "Zwiebel würfeln, 4 Minuten im Öl dünsten und Passata zugeben.",
      "8 Minuten köcheln, abgetropften Dosenthunfisch unterheben und gründlich erwärmen.",
      "Nudeln mit der Sauce vermengen."
    ],
    "tags": [
      "Pasta",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/45.webp"
  },
  {
    "id": "feta-pasta",
    "name": "Ofen-Feta-Tomaten-Pasta",
    "ingredients": [
      {
        "id": "pasta",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "feta",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "tomato",
        "amount": 400,
        "unit": "g"
      },
      {
        "id": "olive_oil",
        "amount": 20,
        "unit": "ml"
      },
      {
        "id": "garlic",
        "amount": 1,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 40,
    "difficulty": "Mittel",
    "category": "Pasta",
    "servings": 2,
    "instructions": [
      "Ofen auf 200 °C Ober-/Unterhitze vorheizen. Kleine Tomaten und gehackten Knoblauch in eine Auflaufform geben.",
      "Feta in die Mitte setzen, alles mit Öl beträufeln und 25–30 Minuten backen.",
      "Währenddessen Nudeln kochen und etwas Kochwasser aufheben.",
      "Feta und Tomaten mit einer Gabel vermischen, Nudeln unterheben und bei Bedarf Kochwasser ergänzen."
    ],
    "tags": [
      "Pasta",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/46.webp"
  },
  {
    "id": "mac-cheese",
    "name": "Mac and Cheese",
    "ingredients": [
      {
        "id": "macaroni",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "cheddar",
        "amount": 120,
        "unit": "g"
      },
      {
        "id": "milk",
        "amount": 300,
        "unit": "ml"
      },
      {
        "id": "butter",
        "amount": 20,
        "unit": "g"
      },
      {
        "id": "flour",
        "amount": 20,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Pasta",
    "servings": 2,
    "instructions": [
      "Makkaroni nach Packungsangabe garen.",
      "Butter in einem Topf schmelzen, Mehl unterrühren und 1 Minute anschwitzen.",
      "Milch nach und nach mit dem Schneebesen einrühren und 5 Minuten sanft köcheln.",
      "Topf vom Herd nehmen, geriebenen Cheddar einrühren und mit den Nudeln mischen."
    ],
    "tags": [
      "Pasta",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/47.webp"
  },
  {
    "id": "gnocchi-tomato",
    "name": "Gnocchi mit Tomate & Mozzarella",
    "ingredients": [
      {
        "id": "gnocchi",
        "amount": 400,
        "unit": "g"
      },
      {
        "id": "passata",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "mozzarella",
        "amount": 125,
        "unit": "g"
      },
      {
        "id": "garlic",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 20,
    "difficulty": "Einfach",
    "category": "Pasta",
    "servings": 2,
    "instructions": [
      "Knoblauch fein hacken und kurz in Öl dünsten. Passata zufügen und 8 Minuten köcheln.",
      "Gnocchi nach Packungsangabe in Wasser garen und abtropfen lassen.",
      "Gnocchi unter die Sauce heben.",
      "Mozzarella zupfen, darüber verteilen und bei milder Hitze schmelzen lassen."
    ],
    "tags": [
      "Pasta",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/48.webp"
  },
  {
    "id": "mushroom-risotto",
    "name": "Cremiges Pilzrisotto",
    "ingredients": [
      {
        "id": "risotto_rice",
        "amount": 180,
        "unit": "g"
      },
      {
        "id": "mushroom",
        "amount": 250,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "parmesan",
        "amount": 40,
        "unit": "g"
      },
      {
        "id": "butter",
        "amount": 20,
        "unit": "g"
      },
      {
        "id": "vegetable_stock",
        "amount": 10,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 40,
    "difficulty": "Mittel",
    "category": "Reis",
    "servings": 2,
    "instructions": [
      "Brühpulver mit 700 ml heißem Wasser verrühren. Pilze schneiden, Zwiebel fein würfeln.",
      "Pilze in der Hälfte der Butter 6 Minuten anbraten und beiseitestellen.",
      "Zwiebel in restlicher Butter dünsten, Reis zugeben und 1 Minute mitrösten.",
      "Heiße Brühe kellenweise zufügen und unter häufigem Rühren 20–25 Minuten garen.",
      "Pilze und geriebenen Parmesan unterheben; bei Bedarf Wasser ergänzen."
    ],
    "tags": [
      "Reis",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/49.webp"
  },
  {
    "id": "pea-risotto",
    "name": "Erbsen-Zitronen-Risotto",
    "ingredients": [
      {
        "id": "risotto_rice",
        "amount": 180,
        "unit": "g"
      },
      {
        "id": "peas",
        "amount": 180,
        "unit": "g"
      },
      {
        "id": "lemon",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "parmesan",
        "amount": 40,
        "unit": "g"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      },
      {
        "id": "vegetable_stock",
        "amount": 10,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 35,
    "difficulty": "Einfach",
    "category": "Reis",
    "servings": 2,
    "instructions": [
      "Brühe in 700 ml heißem Wasser auflösen. Zwiebel würfeln und in Öl dünsten.",
      "Reis zufügen und 1 Minute mitrösten, dann Brühe nach und nach zugießen.",
      "Unter Rühren etwa 20–25 Minuten garen; Erbsen in den letzten 7 Minuten zufügen.",
      "Zitronensaft und Parmesan unterrühren."
    ],
    "tags": [
      "Reis",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/50.webp"
  },
  {
    "id": "couscous-bowl",
    "name": "Couscous-Kichererbsen-Bowl",
    "ingredients": [
      {
        "id": "couscous",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "chickpeas",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "cucumber",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "lemon",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 20,
        "unit": "ml"
      },
      {
        "id": "parsley",
        "amount": 10,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 20,
    "difficulty": "Einfach",
    "category": "Bowls",
    "servings": 2,
    "instructions": [
      "Couscous nach Packungsangabe mit heißem Wasser übergießen und quellen lassen.",
      "Gurke würfeln, Petersilie hacken und gegarte Kichererbsen abspülen.",
      "Couscous mit einer Gabel lockern und mit Gemüse und Kichererbsen vermischen.",
      "Zitronensaft und Öl unterheben."
    ],
    "tags": [
      "Bowls",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/51.webp"
  },
  {
    "id": "bulgur-salad",
    "name": "Bulgur-Tomaten-Salat",
    "ingredients": [
      {
        "id": "bulgur",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "tomato",
        "amount": 3,
        "unit": "Stück"
      },
      {
        "id": "parsley",
        "amount": 20,
        "unit": "g"
      },
      {
        "id": "lemon",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 20,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Salate",
    "servings": 2,
    "instructions": [
      "Bulgur nach Packungsangabe kochen und etwas abkühlen lassen.",
      "Tomaten klein würfeln und Petersilie hacken.",
      "Zitronensaft mit Olivenöl verrühren.",
      "Alles in einer Schüssel mischen und 5 Minuten ziehen lassen."
    ],
    "tags": [
      "Salate",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/52.webp"
  },
  {
    "id": "quinoa-bowl",
    "name": "Quinoa-Avocado-Bowl",
    "ingredients": [
      {
        "id": "quinoa",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "avocado",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "cucumber",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "lemon",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Bowls",
    "servings": 2,
    "instructions": [
      "Quinoa in einem Sieb heiß abspülen, dann nach Packungsangabe kochen.",
      "Avocado entkernen und würfeln, Gurke in kleine Stücke schneiden.",
      "Quinoa kurz ausdampfen lassen und in Schalen verteilen.",
      "Gemüse daraufgeben, Zitronensaft und Öl darüberträufeln."
    ],
    "tags": [
      "Bowls",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/53.webp"
  },
  {
    "id": "greek-salad",
    "name": "Griechischer Bauernsalat",
    "ingredients": [
      {
        "id": "tomato",
        "amount": 3,
        "unit": "Stück"
      },
      {
        "id": "cucumber",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "feta",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "olives",
        "amount": 60,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 20,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 15,
    "difficulty": "Einfach",
    "category": "Salate",
    "servings": 2,
    "instructions": [
      "Tomaten und Gurke grob würfeln, Zwiebel in feine Ringe schneiden.",
      "Mit Oliven in einer Schüssel vermengen.",
      "Feta darüberbröseln und Olivenöl zufügen.",
      "Vorsichtig vermischen; optional mit Oregano würzen."
    ],
    "tags": [
      "Salate",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/54.webp"
  },
  {
    "id": "cucumber-salad",
    "name": "Gurkensalat mit Joghurt & Dill",
    "ingredients": [
      {
        "id": "cucumber",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "yogurt",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "dill",
        "amount": 10,
        "unit": "g"
      },
      {
        "id": "lemon",
        "amount": 0.5,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 15,
    "difficulty": "Einfach",
    "category": "Salate",
    "servings": 2,
    "instructions": [
      "Gurke waschen und sehr fein hobeln.",
      "Joghurt mit Zitronensaft und gehacktem Dill verrühren.",
      "Gurke untermischen und 5 Minuten kühl ziehen lassen."
    ],
    "tags": [
      "Salate",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/55.webp"
  },
  {
    "id": "beetroot-salad",
    "name": "Rote-Bete-Feta-Salat",
    "ingredients": [
      {
        "id": "beetroot",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "feta",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "walnuts",
        "amount": 30,
        "unit": "g"
      },
      {
        "id": "balsamic",
        "amount": 15,
        "unit": "ml"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 60,
    "difficulty": "Mittel",
    "category": "Salate",
    "servings": 2,
    "instructions": [
      "Rote Bete waschen und ungeschält in Wasser je nach Größe 35–50 Minuten weich kochen. Vorgegarte Bete kann direkt verwendet werden.",
      "Kurz abkühlen, schälen und würfeln.",
      "Mit Balsamico und Öl vermischen.",
      "Feta und grob gehackte Walnüsse darübergeben."
    ],
    "tags": [
      "Salate",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/56.webp"
  },
  {
    "id": "carrot-apple",
    "name": "Karotten-Apfel-Salat",
    "ingredients": [
      {
        "id": "carrot",
        "amount": 250,
        "unit": "g"
      },
      {
        "id": "apple",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "lemon",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 15,
    "difficulty": "Einfach",
    "category": "Salate",
    "servings": 2,
    "instructions": [
      "Karotten schälen und raspeln. Apfel waschen, entkernen und ebenfalls raspeln.",
      "Sofort mit Zitronensaft vermengen, damit der Apfel nicht stark nachdunkelt.",
      "Öl unterrühren und kurz ziehen lassen."
    ],
    "tags": [
      "Salate",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/57.webp"
  },
  {
    "id": "potato-egg-salad",
    "name": "Kartoffel-Ei-Salat",
    "ingredients": [
      {
        "id": "potato",
        "amount": 500,
        "unit": "g"
      },
      {
        "id": "egg",
        "amount": 3,
        "unit": "Stück"
      },
      {
        "id": "yogurt",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "mustard",
        "amount": 10,
        "unit": "g"
      },
      {
        "id": "chives",
        "amount": 10,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 40,
    "difficulty": "Mittel",
    "category": "Salate",
    "servings": 2,
    "instructions": [
      "Kartoffeln in Wasser 20–25 Minuten weich kochen. Eier separat 10 Minuten hart kochen.",
      "Beides abkühlen lassen, schälen und in Stücke schneiden.",
      "Joghurt mit Senf und gehacktem Schnittlauch verrühren.",
      "Kartoffeln und Eier vorsichtig mit dem Dressing mischen."
    ],
    "tags": [
      "Salate",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/58.webp"
  },
  {
    "id": "broccoli-chickpea",
    "name": "Brokkoli-Kichererbsen-Salat",
    "ingredients": [
      {
        "id": "broccoli",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "chickpeas",
        "amount": 250,
        "unit": "g"
      },
      {
        "id": "lemon",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 20,
        "unit": "ml"
      },
      {
        "id": "parsley",
        "amount": 10,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      }
    ],
    "time": 20,
    "difficulty": "Einfach",
    "category": "Salate",
    "servings": 2,
    "instructions": [
      "Brokkoli in Röschen teilen und 5–6 Minuten dämpfen, anschließend kurz abkühlen lassen.",
      "Gegarte Kichererbsen abspülen.",
      "Zitronensaft, Öl und gehackte Petersilie verrühren.",
      "Alles vermengen und lauwarm servieren."
    ],
    "tags": [
      "Salate",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/59.webp"
  },
  {
    "id": "tuna-egg-salad",
    "name": "Thunfisch-Ei-Salat mit grünen Bohnen",
    "ingredients": [
      {
        "id": "tuna_canned",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "egg",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "green_beans",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "tomato",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      },
      {
        "id": "lemon",
        "amount": 0.5,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Salate",
    "servings": 2,
    "instructions": [
      "Eier 10 Minuten hart kochen. Grüne Bohnen putzen und in kochendem Wasser mindestens 10 Minuten vollständig garen.",
      "Tomaten schneiden, Dosenthunfisch abtropfen lassen und Eier vierteln.",
      "Bohnen abgießen und kurz abkühlen.",
      "Alles anrichten und mit Zitronensaft und Öl beträufeln."
    ],
    "tags": [
      "Salate",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/60.webp"
  },
  {
    "id": "chicken-broccoli",
    "name": "Hähnchen-Brokkoli-Pfanne",
    "ingredients": [
      {
        "id": "chicken_breast",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "broccoli",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "garlic",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      },
      {
        "id": "soy_sauce",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Hähnchen",
    "servings": 2,
    "instructions": [
      "Brokkoli in Röschen teilen und 5 Minuten dämpfen. Knoblauch hacken.",
      "Hähnchen auf einem separaten Brett in kleine Stücke schneiden; Hände und Arbeitsflächen reinigen.",
      "Hähnchen im Öl 8–10 Minuten rundherum vollständig durchgaren.",
      "Brokkoli, Knoblauch und Sojasauce zufügen und 3 Minuten erhitzen."
    ],
    "tags": [
      "Hähnchen",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/61.webp"
  },
  {
    "id": "chicken-curry",
    "name": "Hähnchen-Kokos-Curry mit Reis",
    "ingredients": [
      {
        "id": "chicken_breast",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "coconut_milk",
        "amount": 200,
        "unit": "ml"
      },
      {
        "id": "rice",
        "amount": 160,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "curry",
        "amount": 1,
        "unit": "TL"
      },
      {
        "id": "neutral_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Hähnchen",
    "servings": 2,
    "instructions": [
      "Reis nach Packungsangabe kochen. Zwiebel würfeln und Hähnchen separat in kleine Stücke schneiden.",
      "Zwiebel in Öl 3 Minuten dünsten, Hähnchen zugeben und 5 Minuten anbraten.",
      "Curry und Kokosmilch hinzufügen, 10–12 Minuten sanft köcheln, bis das Hähnchen vollständig durchgegart ist.",
      "Mit Reis servieren."
    ],
    "tags": [
      "Hähnchen",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/62.webp"
  },
  {
    "id": "turkey-zucchini",
    "name": "Puten-Zucchini-Reis",
    "ingredients": [
      {
        "id": "turkey",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "zucchini",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "rice",
        "amount": 160,
        "unit": "g"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      },
      {
        "id": "garlic",
        "amount": 1,
        "unit": "Stück"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Fleisch",
    "servings": 2,
    "instructions": [
      "Reis nach Packungsangabe kochen. Zucchini würfeln und Knoblauch hacken.",
      "Pute auf separatem Brett in gleichmäßige Streifen schneiden.",
      "Putenstreifen in Öl 8–10 Minuten vollständig durchbraten.",
      "Zucchini und Knoblauch zugeben und 5–7 Minuten garen. Mit Reis anrichten."
    ],
    "tags": [
      "Fleisch",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/63.webp"
  },
  {
    "id": "meatballs",
    "name": "Rinderbällchen in Tomatensauce",
    "ingredients": [
      {
        "id": "ground_beef",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "egg",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "breadcrumbs",
        "amount": 30,
        "unit": "g"
      },
      {
        "id": "passata",
        "amount": 400,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 35,
    "difficulty": "Einfach",
    "category": "Fleisch",
    "servings": 2,
    "instructions": [
      "Zwiebel sehr fein würfeln. Die Hälfte mit Hack, Ei und Paniermehl verkneten und kleine Bällchen formen.",
      "Bällchen in Öl rundherum 6 Minuten anbraten und herausnehmen.",
      "Restliche Zwiebel 3 Minuten dünsten, Passata zugeben und Bällchen wieder einlegen.",
      "Zugedeckt 15–18 Minuten köcheln, bis die Bällchen auch innen vollständig durchgegart sind."
    ],
    "tags": [
      "Fleisch",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/64.webp"
  },
  {
    "id": "beef-pepper",
    "name": "Rindfleisch-Paprika-Pfanne",
    "ingredients": [
      {
        "id": "beef",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "bell_pepper",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "soy_sauce",
        "amount": 20,
        "unit": "ml"
      },
      {
        "id": "neutral_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Fleisch",
    "servings": 2,
    "instructions": [
      "Rindfleisch quer zur Faser in dünne Streifen schneiden. Paprika und Zwiebel ebenfalls in Streifen schneiden.",
      "Fleisch in heißem Öl portionsweise 3–4 Minuten braten und herausnehmen.",
      "Gemüse in der Pfanne 7–8 Minuten braten.",
      "Fleisch und Sojasauce zugeben und weitere 2–3 Minuten erhitzen."
    ],
    "tags": [
      "Fleisch",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/65.webp"
  },
  {
    "id": "pork-mushroom",
    "name": "Schweinemedaillons in Pilzrahm",
    "ingredients": [
      {
        "id": "pork",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "mushroom",
        "amount": 250,
        "unit": "g"
      },
      {
        "id": "cream",
        "amount": 150,
        "unit": "ml"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "neutral_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Fleisch",
    "servings": 2,
    "instructions": [
      "Schweinefilet in etwa 2 cm dicke Medaillons schneiden. Pilze schneiden und Zwiebel würfeln.",
      "Fleisch in heißem Öl portionsweise 5 Minuten anbraten, dann herausnehmen.",
      "Pilze und Zwiebel 7 Minuten braten.",
      "Sahne und Fleisch zugeben und 8–10 Minuten sanft garen, bis das Fleisch vollständig durchgegart ist."
    ],
    "tags": [
      "Fleisch",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/66.webp"
  },
  {
    "id": "salmon-potato",
    "name": "Ofenlachs mit Kartoffeln",
    "ingredients": [
      {
        "id": "salmon",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "potato",
        "amount": 500,
        "unit": "g"
      },
      {
        "id": "lemon",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 20,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 45,
    "difficulty": "Mittel",
    "category": "Fisch",
    "servings": 2,
    "instructions": [
      "Ofen auf 200 °C Ober-/Unterhitze vorheizen. Kartoffeln in dünne Spalten schneiden.",
      "Mit der Hälfte des Öls vermengen und auf Backpapier 25 Minuten backen.",
      "Lachs dazulegen, mit restlichem Öl und Zitronensaft beträufeln.",
      "Weitere 12–18 Minuten je nach Filetdicke backen, bis Lachs durchgegart und Kartoffeln weich sind."
    ],
    "tags": [
      "Fisch",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/67.webp"
  },
  {
    "id": "cod-tomato",
    "name": "Kabeljau in Tomatensauce",
    "ingredients": [
      {
        "id": "cod",
        "amount": 300,
        "unit": "g"
      },
      {
        "id": "passata",
        "amount": 350,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "garlic",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 25,
    "difficulty": "Einfach",
    "category": "Fisch",
    "servings": 2,
    "instructions": [
      "Zwiebel und Knoblauch fein schneiden und 4 Minuten im Öl dünsten.",
      "Passata zugeben und 5 Minuten köcheln.",
      "Kabeljau in die Sauce legen, abdecken und bei milder Hitze 10–15 Minuten gar ziehen lassen.",
      "Der Fisch ist fertig, wenn er vollständig undurchsichtig ist und sich leicht teilen lässt."
    ],
    "tags": [
      "Fisch",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/68.webp"
  },
  {
    "id": "shrimp-rice",
    "name": "Garnelen-Paprika-Reispfanne",
    "ingredients": [
      {
        "id": "shrimp",
        "amount": 250,
        "unit": "g"
      },
      {
        "id": "rice",
        "amount": 160,
        "unit": "g"
      },
      {
        "id": "bell_pepper",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "garlic",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Fisch",
    "servings": 2,
    "instructions": [
      "Reis nach Packungsangabe kochen. Paprika klein würfeln und Knoblauch hacken.",
      "Paprika in Öl 6 Minuten anbraten.",
      "Geschälte Garnelen und Knoblauch zugeben und unter Wenden 5–6 Minuten vollständig garen.",
      "Reis unterheben und alles gründlich erwärmen."
    ],
    "tags": [
      "Fisch",
      "High Protein",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/69.webp"
  },
  {
    "id": "stuffed-pepper",
    "name": "Gefüllte Paprika mit Reis & Feta",
    "ingredients": [
      {
        "id": "bell_pepper",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "rice",
        "amount": 120,
        "unit": "g"
      },
      {
        "id": "feta",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "passata",
        "amount": 250,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 10,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 55,
    "difficulty": "Mittel",
    "category": "Vegetarisch",
    "servings": 2,
    "instructions": [
      "Ofen auf 190 °C Ober-/Unterhitze vorheizen. Reis nach Packungsangabe garen.",
      "Zwiebel würfeln, 4 Minuten in Öl dünsten und mit Reis und zerbröseltem Feta mischen.",
      "Paprika halbieren, entkernen und mit der Mischung füllen.",
      "Passata mit 100 ml Wasser in eine Form geben, Paprika hineinsetzen und 30–35 Minuten backen."
    ],
    "tags": [
      "Vegetarisch",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/70.webp"
  },
  {
    "id": "sweet-potato",
    "name": "Ofen-Süßkartoffeln mit Kichererbsen",
    "ingredients": [
      {
        "id": "sweet_potato",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "chickpeas",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "yogurt",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "olive_oil",
        "amount": 15,
        "unit": "ml"
      },
      {
        "id": "cumin",
        "amount": 0.5,
        "unit": "TL"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 60,
    "difficulty": "Mittel",
    "category": "Kartoffeln",
    "servings": 2,
    "instructions": [
      "Ofen auf 200 °C Ober-/Unterhitze vorheizen. Süßkartoffeln waschen, längs halbieren und mit etwas Öl bestreichen.",
      "Mit der Schnittfläche nach unten 40–50 Minuten weich backen.",
      "Gegarte Kichererbsen mit restlichem Öl und Kreuzkümmel mischen und in den letzten 15 Minuten mitbacken.",
      "Süßkartoffeln auflockern, mit Kichererbsen und Joghurt anrichten."
    ],
    "tags": [
      "Kartoffeln",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/71.webp"
  },
  {
    "id": "zucchini-fritters",
    "name": "Zucchini-Puffer mit Joghurt",
    "ingredients": [
      {
        "id": "zucchini",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "egg",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "flour",
        "amount": 60,
        "unit": "g"
      },
      {
        "id": "yogurt",
        "amount": 150,
        "unit": "g"
      },
      {
        "id": "neutral_oil",
        "amount": 25,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 30,
    "difficulty": "Einfach",
    "category": "Vegetarisch",
    "servings": 2,
    "instructions": [
      "Zucchini grob raspeln und in einem sauberen Tuch gründlich ausdrücken.",
      "Mit Eiern und Mehl vermengen.",
      "Öl in einer Pfanne erhitzen und kleine flache Puffer portionsweise pro Seite 3–4 Minuten goldbraun und vollständig durchbacken.",
      "Mit Joghurt servieren."
    ],
    "tags": [
      "Vegetarisch",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/72.webp"
  },
  {
    "id": "potato-pancakes",
    "name": "Kartoffelpuffer mit Apfelmus",
    "ingredients": [
      {
        "id": "potato",
        "amount": 600,
        "unit": "g"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "egg",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "flour",
        "amount": 30,
        "unit": "g"
      },
      {
        "id": "neutral_oil",
        "amount": 40,
        "unit": "ml"
      },
      {
        "id": "applesauce",
        "amount": 150,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 35,
    "difficulty": "Einfach",
    "category": "Kartoffeln",
    "servings": 2,
    "instructions": [
      "Kartoffeln und Zwiebel schälen und fein reiben. In einem Tuch gut ausdrücken.",
      "Mit Ei und Mehl vermengen.",
      "Öl erhitzen, kleine dünne Puffer formen und portionsweise pro Seite 4–5 Minuten knusprig und durchgegart braten.",
      "Kurz auf Küchenpapier abtropfen lassen und mit Apfelmus servieren."
    ],
    "tags": [
      "Kartoffeln",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/73.webp"
  },
  {
    "id": "cauliflower-bake",
    "name": "Blumenkohl-Käse-Auflauf",
    "ingredients": [
      {
        "id": "cauliflower",
        "amount": 600,
        "unit": "g"
      },
      {
        "id": "milk",
        "amount": 250,
        "unit": "ml"
      },
      {
        "id": "cheese",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "flour",
        "amount": 20,
        "unit": "g"
      },
      {
        "id": "butter",
        "amount": 20,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 40,
    "difficulty": "Mittel",
    "category": "Vegetarisch",
    "servings": 2,
    "instructions": [
      "Ofen auf 200 °C Ober-/Unterhitze vorheizen. Blumenkohl in Röschen teilen und 7 Minuten in Wasser vorgaren.",
      "Butter schmelzen, Mehl einrühren und Milch nach und nach zugeben. Unter Rühren 5 Minuten köcheln.",
      "Blumenkohl in eine Form geben, Sauce darüber verteilen und mit Käse bestreuen.",
      "20 Minuten goldbraun überbacken."
    ],
    "tags": [
      "Vegetarisch",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/74.webp"
  },
  {
    "id": "ratatouille",
    "name": "Ratatouille",
    "ingredients": [
      {
        "id": "aubergine",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "zucchini",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "bell_pepper",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "tomato",
        "amount": 3,
        "unit": "Stück"
      },
      {
        "id": "onion",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "garlic",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "olive_oil",
        "amount": 25,
        "unit": "ml"
      }
    ],
    "optionalIngredients": [
      {
        "id": "salt",
        "amount": 1,
        "unit": "g"
      },
      {
        "id": "pepper",
        "amount": 0.2,
        "unit": "g"
      },
      {
        "id": "parsley",
        "amount": 3,
        "unit": "g"
      }
    ],
    "time": 40,
    "difficulty": "Mittel",
    "category": "Vegetarisch",
    "servings": 2,
    "instructions": [
      "Gemüse waschen und in gleichmäßige Würfel schneiden. Zwiebel und Knoblauch hacken.",
      "Aubergine in der Hälfte des Öls 7 Minuten braten und beiseitestellen.",
      "Restliches Öl erhitzen, Zwiebel, Paprika und Zucchini 6 Minuten braten.",
      "Knoblauch, Tomaten und Aubergine zugeben. Zugedeckt 20 Minuten sanft schmoren, gelegentlich umrühren."
    ],
    "tags": [
      "Vegetarisch",
      "Vegetarisch",
      "Mittagessen",
      "Abendessen"
    ],
    "image": "assets/food/75.webp"
  },
  {
    "id": "apple-crumble",
    "name": "Warmer Apfel-Crumble",
    "ingredients": [
      {
        "id": "apple",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "flour",
        "amount": 80,
        "unit": "g"
      },
      {
        "id": "butter",
        "amount": 50,
        "unit": "g"
      },
      {
        "id": "sugar",
        "amount": 40,
        "unit": "g"
      },
      {
        "id": "cinnamon",
        "amount": 0.5,
        "unit": "TL"
      }
    ],
    "optionalIngredients": [],
    "time": 40,
    "difficulty": "Mittel",
    "category": "Desserts",
    "servings": 2,
    "instructions": [
      "Ofen auf 190 °C Ober-/Unterhitze vorheizen. Äpfel entkernen und in kleine Stücke schneiden.",
      "Äpfel mit Zimt in eine kleine Auflaufform geben.",
      "Mehl, Zucker und kalte Butter mit den Fingern zu Streuseln verreiben und auf den Äpfeln verteilen.",
      "25–30 Minuten backen, bis die Streusel goldbraun und die Äpfel weich sind."
    ],
    "tags": [
      "Desserts",
      "Vegetarisch"
    ],
    "image": "assets/food/76.webp"
  },
  {
    "id": "chocolate-mousse",
    "name": "Schoko-Bananen-Mousse",
    "ingredients": [
      {
        "id": "banana",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "quark",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "cocoa",
        "amount": 20,
        "unit": "g"
      },
      {
        "id": "honey",
        "amount": 15,
        "unit": "g"
      }
    ],
    "optionalIngredients": [],
    "time": 10,
    "difficulty": "Einfach",
    "category": "Desserts",
    "servings": 2,
    "instructions": [
      "Reife Bananen schälen und in Stücke schneiden.",
      "Mit Quark, Kakao und Honig sehr fein pürieren.",
      "Auf zwei Dessertgläser verteilen und sofort servieren oder abgedeckt kühlen."
    ],
    "tags": [
      "Desserts",
      "Vegetarisch"
    ],
    "image": "assets/food/77.webp"
  },
  {
    "id": "lemon-quark",
    "name": "Zitronen-Quark im Glas",
    "ingredients": [
      {
        "id": "quark",
        "amount": 250,
        "unit": "g"
      },
      {
        "id": "yogurt",
        "amount": 100,
        "unit": "g"
      },
      {
        "id": "lemon",
        "amount": 0.5,
        "unit": "Stück"
      },
      {
        "id": "sugar",
        "amount": 25,
        "unit": "g"
      }
    ],
    "optionalIngredients": [
      {
        "id": "oats",
        "amount": 20,
        "unit": "g"
      }
    ],
    "time": 10,
    "difficulty": "Einfach",
    "category": "Desserts",
    "servings": 2,
    "instructions": [
      "Zitrone heiß waschen, etwas Schale fein abreiben und den Saft auspressen.",
      "Quark und Joghurt glatt rühren. Zucker, etwas Zitronenabrieb und Saft nach Geschmack unterrühren.",
      "In Gläser füllen und bis zum Servieren kühl halten.",
      "Optional Haferflocken in einer trockenen Pfanne 2 Minuten rösten, abkühlen lassen und als knusprige Schicht in die Gläser geben."
    ],
    "tags": [
      "Desserts",
      "Vegetarisch"
    ],
    "image": "assets/food/78.webp"
  },
  {
    "id": "banana-bread",
    "name": "Saftiges Bananenbrot",
    "ingredients": [
      {
        "id": "banana",
        "amount": 3,
        "unit": "Stück"
      },
      {
        "id": "flour",
        "amount": 200,
        "unit": "g"
      },
      {
        "id": "egg",
        "amount": 2,
        "unit": "Stück"
      },
      {
        "id": "butter",
        "amount": 70,
        "unit": "g"
      },
      {
        "id": "sugar",
        "amount": 60,
        "unit": "g"
      },
      {
        "id": "baking_powder",
        "amount": 8,
        "unit": "g"
      }
    ],
    "optionalIngredients": [],
    "time": 65,
    "difficulty": "Mittel",
    "category": "Backen",
    "servings": 6,
    "instructions": [
      "Ofen auf 175 °C Ober-/Unterhitze vorheizen. Kleine Kastenform mit Backpapier auslegen.",
      "Weiche Butter und Zucker verrühren, Eier einzeln einrühren. Bananen zerdrücken und hinzufügen.",
      "Mehl und Backpulver mischen und kurz unterheben.",
      "In die Form füllen und 45–50 Minuten backen. Mit einem Holzstäbchen prüfen, ob noch roher Teig anhaftet.",
      "Vor dem Anschneiden mindestens 10 Minuten abkühlen lassen."
    ],
    "tags": [
      "Backen",
      "Vegetarisch"
    ],
    "image": "assets/food/79.webp"
  },
  {
    "id": "blueberry-muffins",
    "name": "Blaubeer-Muffins",
    "ingredients": [
      {
        "id": "flour",
        "amount": 180,
        "unit": "g"
      },
      {
        "id": "blueberry",
        "amount": 120,
        "unit": "g"
      },
      {
        "id": "egg",
        "amount": 1,
        "unit": "Stück"
      },
      {
        "id": "milk",
        "amount": 100,
        "unit": "ml"
      },
      {
        "id": "neutral_oil",
        "amount": 50,
        "unit": "ml"
      },
      {
        "id": "sugar",
        "amount": 70,
        "unit": "g"
      },
      {
        "id": "baking_powder",
        "amount": 6,
        "unit": "g"
      }
    ],
    "optionalIngredients": [],
    "time": 40,
    "difficulty": "Mittel",
    "category": "Backen",
    "servings": 6,
    "instructions": [
      "Ofen auf 180 °C Ober-/Unterhitze vorheizen. Sechs Muffinmulden mit Papierförmchen auslegen.",
      "Mehl, Zucker und Backpulver mischen. Ei, Milch und Öl separat verrühren.",
      "Flüssige Mischung kurz unter die trockenen Zutaten rühren und Blaubeeren vorsichtig unterheben.",
      "Auf die Förmchen verteilen und 22–25 Minuten backen. Stäbchenprobe machen und abkühlen lassen."
    ],
    "tags": [
      "Backen",
      "Vegetarisch"
    ],
    "image": "assets/food/80.webp"
  }
];
root.MiseRecipes=recipes;if(typeof module!=='undefined')module.exports=recipes;
})(typeof window!=='undefined'?window:globalThis);
